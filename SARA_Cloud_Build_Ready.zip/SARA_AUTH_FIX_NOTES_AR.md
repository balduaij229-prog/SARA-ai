# سارة – فحص وإصلاح تجهيز تسجيل الدخول (19 نوفمبر 2026)

## الذي تغيّر
- أزيل الربط الإلزامي بتوقيع debug.keystore المفقود من إعدادات Build Debug، واستُخدم توقيع Android Studio الافتراضي بدلاً منه.
- أُضيف فحص بسيط لمعرّف Web OAuth Client ورسائل تشخيص منفصلة لأخطاء Credentials وFirebase.
- لم يتغير package/applicationId ولا مشروع Firebase ولا أي قاعدة بيانات، ولم يُفعّل دفع أو نشر.

## المطلوب للتجربة الفعلية
1. افتح هذا المشروع في Android Studio بعد فك ZIP، ودع Gradle Sync يكتمل.
2. استخرج SHA-1 وSHA-256 لشهادة **التوقيع التي ستوقّع APK الفعلي**. في مشروع Android Studio، شغّل Gradle task `signingReport`، أو افحص ملف `~/.android/debug.keystore` عبر:
   `keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android`
3. في Firebase Console، افتح المشروع `sara-ai-513013` ثم Project settings → Your apps → تطبيق Android ذو المعرّف `com.aistudio.saraai.kbzqux`، وأضف SHA-1 وSHA-256 الخاصتين بهذه النسخة.
4. في Authentication → Sign-in method، تأكد من تمكين Google. نزّل `google-services.json` المحدث واستبدله في `app/google-services.json` بعد إضافة بصمات التوقيع.
5. ابْنِ Debug APK وجرب تسجيل الدخول. إذا أخفق، راجع رسالة الشاشة وLogcat بكلمة `AuthScreen`.

## حدود الفحص
- وجود بصمة SHA-1 مختلفة في google-services.json القديم ليس دليلاً وحده على سبب العطل؛ يحتاج مقارنة بالبصمة الحقيقية للـAPK.
- إذا كان عندك APK قديم مثبت وموقّع بمفتاح مختلف، لن تقبل أندرويد تحديثه مباشرة. احفظ البيانات المهمة أولاً قبل إزالة النسخة القديمة، ولا تحذفها عشوائياً.
- هذا ZIP **مصدر مُعدّل وغير مبني أو مجرب على الهاتف**. لم تتوفر هنا Android SDK وGradle لبناء APK والتحقق منه.
- `gradle-wrapper.jar` و`gradlew` غير موجودين في المصدر الأصلي؛ Android Studio قد يحتاج تهيئة Gradle محلياً.
- هذه التعديلات تحسّن إمكانية البناء والتشخيص، لكن لا تؤكد حل تسجيل الدخول حتى نفحص توقيع التطبيق وإعدادات Firebase ونتيجة التجربة.


> ملاحظة أحدث: تم إلغاء تسجيل الدخول كاملاً في إصدار SARA_NO_LOGIN_README_AR.md. تعليمات SHA-1 لدخول Google لم تعد لازمة بهذا الفرع.
