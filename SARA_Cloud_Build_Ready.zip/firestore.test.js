const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user: cannot read user memories", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("memories").get());
});

test("Cross-user access: Bob cannot read Alice's conversations or memories", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(ALICE_UID).collection("memories").doc("mem1").set({
      userId: ALICE_UID,
      title: "Favorite Food",
      content: "Loves Majboos Laham with Dakous",
      category: "preference",
      importance: 5,
      createdAt: new Date(),
    });
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(bobDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem1").get());
});

test("Authenticated owner: can create and read their own memory", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const memRef = aliceDb.collection("users").doc(ALICE_UID).collection("memories").doc("mem1");

  await assertSucceeds(
    memRef.set({
      userId: ALICE_UID,
      title: "Work Routine",
      content: "Works in Sharq, Kuwait City",
      category: "work",
      importance: 4,
      createdAt: new Date(),
    })
  );

  await assertSucceeds(memRef.get());
});

test("Authenticated owner: can create conversation and messages", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const convRef = aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv1");

  await assertSucceeds(
    convRef.set({
      userId: ALICE_UID,
      title: "Trip to Shuwaikh",
      lastMessage: "Where is the best cafe in Shuwaikh?",
      messageCount: 1,
      createdAt: new Date(),
    })
  );

  const msgRef = convRef.collection("messages").doc("msg1");
  await assertSucceeds(
    msgRef.set({
      userId: ALICE_UID,
      role: "user",
      content: "وين أحسن كافيه في الشويخ الصناعية؟",
      attachmentType: "none",
      createdAt: new Date(),
    })
  );
});

test("Messages are append-only: Alice cannot update or delete messages", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context.firestore().collection("users").doc(ALICE_UID).collection("conversations").doc("conv1").collection("messages").doc("msg1").set({
      userId: ALICE_UID,
      role: "user",
      content: "Hello",
      attachmentType: "none",
      createdAt: new Date(),
    });
  });

  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const msgRef = aliceDb.collection("users").doc(ALICE_UID).collection("conversations").doc("conv1").collection("messages").doc("msg1");

  await assertFails(msgRef.update({ content: "Modified content" }));
  await assertFails(msgRef.delete());
});
