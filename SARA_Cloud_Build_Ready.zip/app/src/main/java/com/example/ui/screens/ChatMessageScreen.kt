package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Message
import com.example.ui.components.DateSeparatorChip
import com.example.ui.components.EmptyChatSuggestionsView
import com.example.ui.components.StreamingAiBubble
import com.example.ui.components.formatDateHeader
import com.example.ui.components.formatMessageTime
import com.example.ui.components.getDateKey
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraBubble
import com.example.ui.theme.SaraBubbleBorder
import com.example.ui.theme.SaraBubbleSecondary
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.SaraTeal
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.UserBubble
import com.example.ui.theme.UserBubbleBorder
import com.example.ui.theme.UserBubbleSecondary
import com.example.ui.viewmodel.SaraViewModel
import kotlinx.coroutines.launch

/**
 * Styling descriptor that distinguishes User messages from SARA AI responses
 * via bubble colors, gradients, borders, corner shapes, and horizontal alignments.
 */
data class MessageBubbleStyle(
    val isUser: Boolean,
    val bubbleColor: Color,
    val secondaryBubbleColor: Color,
    val borderColor: Color,
    val headerLabel: String,
    val headerColor: Color,
    val horizontalArrangement: Arrangement.Horizontal,
    val columnAlignment: Alignment.Horizontal,
    val boxAlignment: Alignment,
    val cornerShape: RoundedCornerShape,
    val rowTestTag: String,
    val bubbleTestTag: String
)

/**
 * Resolves the distinct visual styling and alignment for a chat message based on its sender role.
 * - User messages ("user"): End-aligned (`Arrangement.End` / `Alignment.End`), warm royal-teal bubble (`UserBubble`),
 *   gold/teal accent border, and bottom-end speech tail.
 * - SARA AI responses ("model" / "assistant"): Start-aligned (`Arrangement.Start` / `Alignment.Start`),
 *   deep obsidian-indigo bubble (`SaraBubble`), cyan/emerald accent border, and bottom-start speech tail.
 */
fun resolveMessageBubbleStyle(role: String, isSpeaking: Boolean = false): MessageBubbleStyle {
    val isUser = role.equals("user", ignoreCase = true)
    return if (isUser) {
        MessageBubbleStyle(
            isUser = true,
            bubbleColor = UserBubble,
            secondaryBubbleColor = UserBubbleSecondary,
            borderColor = UserBubbleBorder.copy(alpha = 0.5f),
            headerLabel = "أنت",
            headerColor = KuwaitGold,
            horizontalArrangement = Arrangement.End,
            columnAlignment = Alignment.End,
            boxAlignment = Alignment.CenterEnd,
            cornerShape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = 20.dp,
                bottomEnd = 4.dp
            ),
            rowTestTag = "user_message_row",
            bubbleTestTag = "message_bubble_user"
        )
    } else {
        MessageBubbleStyle(
            isUser = false,
            bubbleColor = SaraBubble,
            secondaryBubbleColor = SaraBubbleSecondary,
            borderColor = if (isSpeaking) KuwaitEmerald.copy(alpha = 0.7f) else SaraBubbleBorder.copy(alpha = 0.4f),
            headerLabel = "سارة • ذكاء كويتي 🇰🇼",
            headerColor = if (isSpeaking) KuwaitEmerald else SaraCyan,
            horizontalArrangement = Arrangement.Start,
            columnAlignment = Alignment.Start,
            boxAlignment = Alignment.CenterStart,
            cornerShape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = 4.dp,
                bottomEnd = 20.dp
            ),
            rowTestTag = "sara_message_row",
            bubbleTestTag = "message_bubble_model"
        )
    }
}

/**
 * ViewModel-backed overload of [ChatMessageScreen] that observes chat history directly
 * from [SaraViewModel] and renders it in a [LazyColumn].
 */
@Composable
fun ChatMessageScreen(
    viewModel: SaraViewModel,
    modifier: Modifier = Modifier,
    isSpeaking: Boolean = false,
    currentUtteranceId: String? = null,
    onSpeakMessage: (Message) -> Unit = {},
    onStopSpeaking: () -> Unit = {},
    onSelectSuggestion: (String) -> Unit = { prompt -> viewModel.sendMessage(prompt) },
    listState: LazyListState = rememberLazyListState()
) {
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingChunk by viewModel.streamingResponse.collectAsState()

    ChatMessageScreen(
        messages = messages,
        isGenerating = isGenerating,
        streamingChunk = streamingChunk,
        isSpeaking = isSpeaking,
        currentUtteranceId = currentUtteranceId,
        onSpeakMessage = onSpeakMessage,
        onStopSpeaking = onStopSpeaking,
        onSelectSuggestion = onSelectSuggestion,
        modifier = modifier,
        listState = listState
    )
}

/**
 * ChatMessageScreen composable using a [LazyColumn] to display the chronological chat history
 * between the user and SARA AI, styled with distinct bubble colors and alignments.
 */
@Composable
fun ChatMessageScreen(
    messages: List<Message>,
    modifier: Modifier = Modifier,
    isGenerating: Boolean = false,
    streamingChunk: String = "",
    isSpeaking: Boolean = false,
    currentUtteranceId: String? = null,
    onSpeakMessage: (Message) -> Unit = {},
    onStopSpeaking: () -> Unit = {},
    onSelectSuggestion: (String) -> Unit = {},
    listState: LazyListState = rememberLazyListState()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Sort messages strictly in chronological order (oldest to newest)
    val chronologicalMessages = remember(messages) {
        messages.sortedWith(
            compareBy<Message> { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                .thenBy { it.id }
        )
    }

    // Determine whether the user has scrolled up away from the latest message
    val showScrollToBottom by remember {
        derivedStateOf {
            val totalItems = chronologicalMessages.size + if (isGenerating) 1 else 0
            if (totalItems <= 3) {
                false
            } else {
                val lastVisibleItemIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                lastVisibleItemIndex < totalItems - 2
            }
        }
    }

    // Automatically scroll to the newest message when a message arrives or streams
    LaunchedEffect(chronologicalMessages.size, streamingChunk) {
        val totalCount = chronologicalMessages.size + if (isGenerating) 1 else 0
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(SaraDeepObsidian)
                .testTag("chat_message_screen")
        ) {
            if (chronologicalMessages.isEmpty() && !isGenerating) {
                EmptyChatSuggestionsView(onSelectSuggestion = onSelectSuggestion)
            } else {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp)
                        .testTag("chat_messages_list"),
                    contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Subtle header badge showing total messages in history
                    item(key = "history_count_header") {
                        ChatHistoryHeaderBadge(messageCount = chronologicalMessages.size)
                    }

                    // Render messages with date group separators and role-based bubble styling
                    items(
                        items = chronologicalMessages,
                        key = { msg -> msg.id.ifBlank { "${msg.role}_${msg.createdAt?.seconds ?: 0}_${msg.content.hashCode()}" } }
                    ) { msg ->
                        val index = chronologicalMessages.indexOf(msg)
                        val currentDateKey = getDateKey(msg.createdAt)
                        val previousDateKey = if (index > 0) {
                            getDateKey(chronologicalMessages[index - 1].createdAt)
                        } else {
                            ""
                        }

                        val isThisMessageSpeaking = isSpeaking && currentUtteranceId == msg.id
                        val bubbleStyle = resolveMessageBubbleStyle(
                            role = msg.role,
                            isSpeaking = isThisMessageSpeaking
                        )

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (currentDateKey != previousDateKey) {
                                DateSeparatorChip(dateText = formatDateHeader(msg.createdAt))
                            }

                            StyledChatMessageRow(
                                message = msg,
                                style = bubbleStyle,
                                isSpeaking = isThisMessageSpeaking,
                                onCopy = {
                                    copyMessageToClipboard(context, msg.content)
                                },
                                onSpeak = {
                                    if (isThisMessageSpeaking) {
                                        onStopSpeaking()
                                    } else {
                                        onSpeakMessage(msg)
                                    }
                                }
                            )
                        }
                    }

                    // Live streaming bubble when SARA AI is actively generating a response
                    if (isGenerating) {
                        item(key = "streaming_bubble_indicator") {
                            StreamingAiBubble(
                                text = streamingChunk.ifBlank { "سارة تكتب لك الآن..." }
                            )
                        }
                    }
                }
            }

            // Floating Scroll-to-Bottom button when reading older history
            AnimatedVisibility(
                visible = showScrollToBottom,
                enter = fadeIn() + scaleIn(),
                exit = fadeOut() + scaleOut(),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
            ) {
                FloatingActionButton(
                    onClick = {
                        coroutineScope.launch {
                            val totalCount = listState.layoutInfo.totalItemsCount
                            if (totalCount > 0) {
                                listState.animateScrollToItem(totalCount - 1)
                            }
                        }
                    },
                    containerColor = SaraSurfaceElevated,
                    contentColor = SaraCyan,
                    elevation = FloatingActionButtonDefaults.elevation(6.dp),
                    shape = CircleShape,
                    modifier = Modifier
                        .size(42.dp)
                        .border(1.dp, SaraCyan.copy(alpha = 0.4f), CircleShape)
                        .testTag("scroll_to_bottom_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "الانتقال لآخر الرسائل",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}

/**
 * Renders an individual chat message inside the [LazyColumn] with distinct alignment,
 * bubble background gradient/color, border, and avatar based on [MessageBubbleStyle].
 */
@Composable
fun StyledChatMessageRow(
    message: Message,
    style: MessageBubbleStyle,
    isSpeaking: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag(style.rowTestTag),
        contentAlignment = style.boxAlignment
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .testTag(style.bubbleTestTag),
            horizontalArrangement = style.horizontalArrangement,
            verticalAlignment = Alignment.Bottom
        ) {
            // Leading Avatar for SARA AI (Start-aligned)
            if (!style.isUser) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .padding(bottom = 2.dp)
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(SaraSurfaceElevated)
                        .border(
                            width = 1.5.dp,
                            color = if (isSpeaking) KuwaitEmerald else SaraCyan,
                            shape = CircleShape
                        )
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_sara_logo),
                        contentDescription = "سارة",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
            }

            // Styled Message Bubble Column
            Column(
                modifier = Modifier
                    .weight(1f, fill = false)
                    .widthIn(min = 120.dp, max = 320.dp),
                horizontalAlignment = style.columnAlignment
            ) {
                Box(
                    modifier = Modifier
                        .clip(style.cornerShape)
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    style.bubbleColor,
                                    style.secondaryBubbleColor
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            color = style.borderColor,
                            shape = style.cornerShape
                        )
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    Column(
                        horizontalAlignment = style.columnAlignment
                    ) {
                        // Sender Identity Header Row
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = style.horizontalArrangement,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            Text(
                                text = style.headerLabel,
                                style = MaterialTheme.typography.labelSmall,
                                color = style.headerColor,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(style.headerColor)
                            )
                            if (!style.isUser && isSpeaking) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "تتحدث الآن...",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KuwaitEmerald
                                )
                            }
                        }

                        // Attachment Chip if message includes an image or document
                        if (message.attachmentType == "image") {
                            AttachmentTagChip(
                                icon = Icons.Default.Image,
                                label = "مرفق صورة تم تحليلها",
                                accentColor = SaraCyan
                            )
                        } else if (message.attachmentType == "document") {
                            AttachmentTagChip(
                                icon = Icons.Default.AttachFile,
                                label = message.attachmentName ?: "مستند معرفي",
                                accentColor = KuwaitGold
                            )
                        }

                        // Selectable Message Body Text
                        SelectionContainer {
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodyLarge,
                                color = TextWhite,
                                lineHeight = 24.sp,
                                textAlign = TextAlign.Start
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Footer Actions (TTS for SARA, Copy for both, and Timestamp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (!style.isUser) {
                                    IconButton(
                                        onClick = onSpeak,
                                        modifier = Modifier
                                            .size(30.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isSpeaking) KuwaitEmerald.copy(alpha = 0.2f)
                                                else SaraSurfaceElevated
                                            )
                                            .testTag("message_speak_button")
                                    ) {
                                        Icon(
                                            imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                            contentDescription = if (isSpeaking) "إيقاف الصوت" else "استماع لصوت سارة",
                                            tint = if (isSpeaking) KuwaitEmerald else SaraCyan,
                                            modifier = Modifier.size(15.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                }

                                IconButton(
                                    onClick = onCopy,
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(SaraSurfaceDark.copy(alpha = 0.45f))
                                        .testTag(if (style.isUser) "copy_message_button" else "message_copy_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "نسخ النص",
                                        tint = if (style.isUser) SaraTeal else TextGray,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }

                            Text(
                                text = formatMessageTime(message.createdAt),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (style.isUser) TextWhite.copy(alpha = 0.7f) else TextMuted
                            )
                        }
                    }
                }
            }

            // Trailing Avatar for User (End-aligned)
            if (style.isUser) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .padding(bottom = 2.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(UserBubble)
                        .border(1.5.dp, KuwaitGold.copy(alpha = 0.75f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "أنت",
                        tint = KuwaitGold,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun AttachmentTagChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    accentColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(SaraSurfaceDark.copy(alpha = 0.6f))
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(16.dp)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = accentColor,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun ChatHistoryHeaderBadge(messageCount: Int) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            color = SaraSurfaceElevated.copy(alpha = 0.6f),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(0.5.dp, SaraBorderDark)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(SaraCyan, CircleShape)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "سجل المحادثة مع سارة ($messageCount رسالة محفوظة)",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

private fun copyMessageToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("SARA AI Message", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "تم نسخ النص 📋", Toast.LENGTH_SHORT).show()
}
