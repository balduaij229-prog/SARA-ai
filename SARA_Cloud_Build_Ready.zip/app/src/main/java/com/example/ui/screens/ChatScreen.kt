package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.model.Conversation
import com.example.data.model.LearnedDocument
import com.example.data.model.Message
import com.example.ui.components.ActiveReferenceDocumentBanner
import com.example.ui.components.ChatMessageList
import com.example.ui.components.DocumentReferenceSheet
import com.example.ui.components.KuwaitWelcomeAnimationOverlay
import com.example.ui.components.QuickActionsRow
import com.example.ui.components.SaraAvatarStage
import com.example.ui.components.SettingsDrawerContent
import com.example.util.DocumentExtractor
import com.example.ui.theme.ChipBackground
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraBubble
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.UserBubble
import com.example.ui.viewmodel.SaraViewModel
import com.example.util.SaraSttManager
import com.example.util.SaraTtsManager
import com.example.util.SpeechRecognitionState
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader

@Composable
fun ChatScreen(
    viewModel: SaraViewModel
) {
    val context = LocalContext.current
    val conversations by viewModel.conversations.collectAsState()
    val currentConvId by viewModel.currentConversationId.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val streamingChunk by viewModel.streamingResponse.collectAsState()
    val attachedBitmap by viewModel.attachedImageBitmap.collectAsState()
    val attachedDocName by viewModel.attachedFileName.collectAsState()
    val autoSpeakEnabled by viewModel.autoSpeakEnabled.collectAsState()

    val currentVoiceMode by viewModel.voiceMode.collectAsState()
    val memoryPrivacyEnabled by viewModel.memoryPrivacyEnabled.collectAsState()
    val memories by viewModel.memories.collectAsState()

    val selectedRefDoc by viewModel.selectedReferenceDocument.collectAsState()
    val documents by viewModel.documents.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showConversationsMenu by remember { mutableStateOf(false) }
    var showRefDocSheet by remember { mutableStateOf(false) }
    var isUploadingDocument by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    var showWelcomeGreeting by rememberSaveable { mutableStateOf(true) }

    val listState = rememberLazyListState()

    // Dedicated Kuwaiti TTS & STT Managers
    val ttsManager = remember(context) { SaraTtsManager(context) }
    val sttManager = remember(context) { SaraSttManager(context) }

    val isSpeaking by ttsManager.isSpeaking.collectAsState()
    val currentUtteranceId by ttsManager.currentUtteranceId.collectAsState()
    val sttState by sttManager.state.collectAsState()

    DisposableEffect(ttsManager, sttManager) {
        onDispose {
            ttsManager.shutdown()
            sttManager.destroy()
        }
    }

    // Synchronize TTS voice parameters whenever voiceMode changes
    LaunchedEffect(currentVoiceMode) {
        ttsManager.setVoiceMode(currentVoiceMode)
    }

    // Back handling: close drawer if open
    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    // Auto-read response when SARA finishes generating, if auto-speak is enabled
    LaunchedEffect(autoSpeakEnabled) {
        viewModel.lastGeneratedAiResponse.collect { responseText ->
            if (autoSpeakEnabled && responseText.isNotBlank()) {
                ttsManager.speak(responseText)
            }
        }
    }

    // When recognized speech completes, update inputText
    LaunchedEffect(sttState) {
        val state = sttState
        if (state is SpeechRecognitionState.Recognized) {
            if (state.text.isNotBlank()) {
                inputText = state.text
            }
        }
    }

    // Auto scroll when new messages or chunks arrive
    LaunchedEffect(messages.size, streamingChunk) {
        val totalItems = messages.size + if (isGenerating) 1 else 0
        if (totalItems > 0) {
            listState.animateScrollToItem(totalItems - 1)
        }
    }

    // Runtime Permission for Microphone / STT
    val audioPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            sttManager.startListening()
        } else {
            Toast.makeText(
                context,
                "يرجى السماح بإذن الميكروفون للتحدث صوتياً مع سارة",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    fun handleMicClick() {
        if (sttState is SpeechRecognitionState.Listening || sttState is SpeechRecognitionState.Ready) {
            sttManager.stopListening()
        } else {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

            if (hasPermission) {
                sttManager.startListening()
            } else {
                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    // Photo picker (Android Photo Picker zero-permission compliant)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val bitmap = uriToBitmap(context, it)
            if (bitmap != null) {
                viewModel.attachImage(bitmap)
            }
        }
    }

    // Document picker for uploading PDF or text documents to Firestore for context-aware answers
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { selectedUri ->
            coroutineScope.launch {
                isUploadingDocument = true
                try {
                    val result = DocumentExtractor.extract(context, selectedUri)
                    viewModel.uploadAndLearnDocument(
                        fileName = result.fileName,
                        content = result.textContent,
                        bitmap = result.previewBitmap,
                        fileType = result.fileType,
                        fileSizeBytes = result.fileSizeBytes,
                        pageCount = result.pageCount
                    )
                    Toast.makeText(
                        context,
                        "تم رفع المستند واستخراجه بنجاح 📄",
                        Toast.LENGTH_SHORT
                    ).show()
                } catch (e: Exception) {
                    Toast.makeText(
                        context,
                        "فشل في استخراج المستند: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                } finally {
                    isUploadingDocument = false
                }
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            SettingsDrawerContent(
                currentVoiceMode = currentVoiceMode,
                memoryPrivacyEnabled = memoryPrivacyEnabled,
                memories = memories,
                onSelectVoiceMode = { mode ->
                    viewModel.setVoiceMode(mode)
                    ttsManager.setVoiceMode(mode)
                },
                onPreviewVoice = { mode ->
                    ttsManager.setVoiceMode(mode)
                    ttsManager.speak(mode.sampleText)
                },
                onToggleMemoryPrivacy = { viewModel.toggleMemoryPrivacy() },
                onClearAllMemories = { viewModel.clearAllMemories() },
                onDeleteSingleMemory = { memId -> viewModel.deleteMemory(memId) },
                onCloseDrawer = {
                    coroutineScope.launch { drawerState.close() }
                }
            )
        }
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(SaraDeepObsidian)
            ) {
                // Top App Bar
                TopChatBar(
                    conversations = conversations,
                    currentConvId = currentConvId,
                    showMenu = showConversationsMenu,
                    isSpeaking = isSpeaking,
                    autoSpeakEnabled = autoSpeakEnabled,
                    selectedReferenceDocument = selectedRefDoc,
                    onOpenDocumentSheet = { showRefDocSheet = true },
                    onToggleMenu = { showConversationsMenu = !showConversationsMenu },
                    onOpenSettingsDrawer = {
                        coroutineScope.launch { drawerState.open() }
                    },
                    onShowWelcome = { showWelcomeGreeting = true },
                    onToggleAutoSpeak = {
                        viewModel.toggleAutoSpeak()
                        val msg = if (!autoSpeakEnabled) "تم تفعيل القراءة الصوتية التلقائية 🔊" else "تم إيقاف القراءة التلقائية 🔇"
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    },
                    onStopSpeaking = { ttsManager.stop() },
                    onSelectConversation = {
                        viewModel.selectConversation(it)
                        showConversationsMenu = false
                    },
                    onNewConversation = {
                        viewModel.createNewConversation()
                        showConversationsMenu = false
                    },
                    onDeleteConversation = {
                        if (currentConvId != null) {
                            viewModel.deleteConversation(currentConvId!!)
                        }
                    }
                )

        // Speaking indicator banner when SARA is speaking
        AnimatedVisibility(
            visible = isSpeaking,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            SpeakingBanner(
                onStop = { ttsManager.stop() }
            )
        }

        // SARA's large on-screen upper-body avatar, using original user assets.
        SaraAvatarStage(isSpeaking = isSpeaking)

        // ChatMessageScreen displaying chat history between user and SARA AI in a LazyColumn
        ChatMessageScreen(
            messages = messages,
            isGenerating = isGenerating,
            streamingChunk = streamingChunk,
            isSpeaking = isSpeaking,
            currentUtteranceId = currentUtteranceId,
            onSpeakMessage = { msg ->
                ttsManager.speak(msg.content, utteranceId = msg.id)
            },
            onStopSpeaking = { ttsManager.stop() },
            onSelectSuggestion = { suggestion ->
                inputText = suggestion
                viewModel.sendMessage(suggestion)
                inputText = ""
            },
            listState = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        )

        // Active Context-Aware Reference Document Banner
        AnimatedVisibility(
            visible = selectedRefDoc != null,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            if (selectedRefDoc != null) {
                ActiveReferenceDocumentBanner(
                    document = selectedRefDoc!!,
                    onOpenSheet = { showRefDocSheet = true },
                    onClear = {
                        viewModel.selectReferenceDocument(null)
                        Toast.makeText(context, "تم إلغاء المرجع، والعودة للدردشة العامة", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // Document Extraction & Upload Progress Banner
        AnimatedVisibility(
            visible = isUploadingDocument,
            enter = fadeIn() + slideInVertically(),
            exit = fadeOut() + slideOutVertically()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaraSurfaceElevated)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    color = KuwaitGold,
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "جاري استخراج وقراءة محتوى المستند وحفظه في Firestore...",
                    style = MaterialTheme.typography.bodySmall,
                    color = KuwaitGold
                )
            }
        }

        // Quick Actions Row (Contextual one-tap actions: Summarize, Translate, Draft Reply, Explain, or Doc Actions)
        val latestMessage = remember(messages) {
            messages.sortedBy { it.createdAt?.toDate()?.time ?: 0L }.lastOrNull()
        }
        QuickActionsRow(
            lastMessage = latestMessage,
            isGenerating = isGenerating,
            referenceDocument = selectedRefDoc,
            onActionSelected = { prompt ->
                viewModel.sendMessage(prompt)
            }
        )

        // Attached Media Preview
        AnimatedVisibility(visible = attachedBitmap != null || attachedDocName != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaraSurfaceElevated)
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (attachedBitmap != null) {
                    Image(
                        bitmap = attachedBitmap!!.asImageBitmap(),
                        contentDescription = "معاينة الصورة",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "صورة جاهزة للإرسال والتحليل",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextWhite,
                        modifier = Modifier.weight(1f)
                    )
                } else if (attachedDocName != null) {
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = null,
                        tint = KuwaitGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = attachedDocName!!,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "مستند معرفي لتعليم سارة",
                            style = MaterialTheme.typography.labelSmall,
                            color = KuwaitGold
                        )
                    }
                }

                IconButton(
                    onClick = { viewModel.clearAttachment() },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إلغاء المرفق",
                        tint = TextGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Voice Input (STT) Panel when recording or recognizing speech
        AnimatedVisibility(
            visible = sttState !is SpeechRecognitionState.Idle,
            enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
            exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 })
        ) {
            VoiceInteractionPanel(
                state = sttState,
                onSendNow = { recognizedText ->
                    if (recognizedText.isNotBlank()) {
                        sttManager.stopListening()
                        viewModel.sendMessage(recognizedText)
                        inputText = ""
                    }
                },
                onInsertText = { recognizedText ->
                    inputText = recognizedText
                    sttManager.stopListening()
                },
                onCancel = {
                    sttManager.cancelListening()
                },
                onRetry = {
                    handleMicClick()
                }
            )
        }

                // Chat Input Bar with Mic button
                ChatInputBar(
                    text = inputText,
                    onTextChange = { inputText = it },
                    isGenerating = isGenerating,
                    isListening = sttState is SpeechRecognitionState.Listening || sttState is SpeechRecognitionState.Ready,
                    hasActiveDocument = selectedRefDoc != null,
                    hasPendingAttachment = attachedBitmap != null || attachedDocName != null,
                    onSend = {
                        if (inputText.isNotBlank() || attachedBitmap != null || attachedDocName != null) {
                            val promptToSend = inputText
                            inputText = ""
                            viewModel.sendMessage(promptToSend)
                        }
                    },
                    onMicClick = { handleMicClick() },
                    onPickPhoto = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    onPickDocument = {
                        showRefDocSheet = true
                    }
                )
            }

            // Traditional Kuwaiti Welcome Animation Overlay on launch
            KuwaitWelcomeAnimationOverlay(
                visible = showWelcomeGreeting,
                onDismiss = { showWelcomeGreeting = false }
            )

            // Document Reference Selection & Upload Modal Bottom Sheet
            if (showRefDocSheet) {
                DocumentReferenceSheet(
                    documents = documents,
                    currentReference = selectedRefDoc,
                    onSelectDocument = { doc ->
                        viewModel.selectReferenceDocument(doc)
                        showRefDocSheet = false
                        if (doc != null) {
                            Toast.makeText(context, "تم تحديد \"${doc.title}\" كمرجع للإجابة 📚", Toast.LENGTH_SHORT).show()
                        }
                    },
                    onUploadNewClick = {
                        showRefDocSheet = false
                        documentPickerLauncher.launch(
                            arrayOf(
                                "application/pdf",
                                "text/plain",
                                "text/*",
                                "application/json",
                                "text/csv"
                            )
                        )
                    },
                    onDismiss = { showRefDocSheet = false }
                )
            }
        }
    }
}

/**
 * Top App Bar with auto-speak toggle, settings drawer access, and SARA voice status
 */
@Composable
private fun TopChatBar(
    conversations: List<Conversation>,
    currentConvId: String?,
    showMenu: Boolean,
    isSpeaking: Boolean,
    autoSpeakEnabled: Boolean,
    selectedReferenceDocument: LearnedDocument?,
    onOpenDocumentSheet: () -> Unit,
    onToggleMenu: () -> Unit,
    onOpenSettingsDrawer: () -> Unit,
    onShowWelcome: () -> Unit,
    onToggleAutoSpeak: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSelectConversation: (String) -> Unit,
    onNewConversation: () -> Unit,
    onDeleteConversation: () -> Unit
) {
    Surface(
        color = SaraSurfaceDark,
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, if (isSpeaking) KuwaitEmerald else SaraCyan, CircleShape)
                    .clickable(onClick = onShowWelcome),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_sara_logo),
                    contentDescription = "سارة - اضغط للترحيب",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "سارة • SARA AI",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (isSpeaking) KuwaitEmerald else SaraCyan)
                    )
                }
                Text(
                    text = if (isSpeaking) "تتحدث الآن بصوتها الكويتي 🔊" else "متصلة • صوت ولهجة كويتية 🇰🇼",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSpeaking) KuwaitEmerald else SaraCyan
                )
            }

            // Settings Drawer Button (Voice Modes & Firestore Memory Privacy)
            IconButton(
                onClick = onOpenSettingsDrawer,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("settings_drawer_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "إعدادات نمط الصوت والخصوصية",
                    tint = KuwaitGold
                )
            }

            // Auto-speak toggle button
            IconButton(
                onClick = onToggleAutoSpeak,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("auto_speak_toggle")
            ) {
                Icon(
                    imageVector = if (autoSpeakEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                    contentDescription = if (autoSpeakEnabled) "القراءة التلقائية مفعلة" else "القراءة التلقائية معطلة",
                    tint = if (autoSpeakEnabled) SaraCyan else TextMuted
                )
            }

            // Stop speaking button if currently playing audio
            if (isSpeaking) {
                IconButton(
                    onClick = onStopSpeaking,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE11D48).copy(alpha = 0.2f))
                        .testTag("stop_speech_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Stop,
                        contentDescription = "إيقاف الصوت",
                        tint = Color(0xFFF43F5E)
                    )
                }
            }

            // Reference Document Picker Button in TopChatBar
            IconButton(
                onClick = onOpenDocumentSheet,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(if (selectedReferenceDocument != null) KuwaitGold.copy(alpha = 0.2f) else Color.Transparent)
                    .testTag("open_reference_doc_button")
            ) {
                Icon(
                    imageVector = if (selectedReferenceDocument != null) Icons.Default.Description else Icons.Default.AttachFile,
                    contentDescription = "المستندات المرجعية للإجابة",
                    tint = if (selectedReferenceDocument != null) KuwaitGold else TextGray
                )
            }

            // New Conversation Button
            IconButton(
                onClick = onNewConversation,
                modifier = Modifier
                    .size(38.dp)
                    .testTag("new_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "محادثة جديدة",
                    tint = SaraCyan
                )
            }

            // Conversations List Menu
            Box {
                IconButton(
                    onClick = onToggleMenu,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.SmartToy,
                        contentDescription = "قائمة المحادثات",
                        tint = TextGray
                    )
                }

                DropdownMenu(
                    expanded = showMenu,
                    onDismissRequest = onToggleMenu,
                    modifier = Modifier.background(SaraSurfaceElevated)
                ) {
                    DropdownMenuItem(
                        text = { Text("+ محادثة جديدة", color = SaraCyan, fontWeight = FontWeight.Bold) },
                        onClick = onNewConversation
                    )
                    if (conversations.isEmpty()) {
                        DropdownMenuItem(
                            text = { Text("لا توجد محادثات سابقة", color = TextMuted) },
                            onClick = {}
                        )
                    } else {
                        conversations.forEach { conv ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = conv.title.ifBlank { "محادثة" },
                                        color = if (conv.id == currentConvId) SaraCyan else TextWhite,
                                        fontWeight = if (conv.id == currentConvId) FontWeight.Bold else FontWeight.Normal
                                    )
                                },
                                onClick = { onSelectConversation(conv.id) }
                            )
                        }
                    }
                }
            }

            if (currentConvId != null) {
                IconButton(
                    onClick = onDeleteConversation,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "حذف المحادثة الحالية",
                        tint = TextMuted
                    )
                }
            }
        }
    }
}

/**
 * Animated banner displayed while SARA is speaking aloud
 */
@Composable
private fun SpeakingBanner(
    onStop: () -> Unit
) {
    Surface(
        color = SaraSurfaceElevated,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = KuwaitEmerald,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "سارة تقرأ لك بصوتها الكويتي الدافئ...",
                    style = MaterialTheme.typography.bodySmall,
                    color = KuwaitEmerald,
                    fontWeight = FontWeight.Medium
                )
            }

            Button(
                onClick = onStop,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFE11D48).copy(alpha = 0.2f),
                    contentColor = Color(0xFFF43F5E)
                ),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(28.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "إيقاف", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

/**
 * Hands-Free Voice Interaction Panel (STT)
 */
@Composable
private fun VoiceInteractionPanel(
    state: SpeechRecognitionState,
    onSendNow: (String) -> Unit,
    onInsertText: (String) -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "mic_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        color = SaraSurfaceElevated,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, SaraCyan.copy(alpha = 0.4f), RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (state) {
                is SpeechRecognitionState.Ready, is SpeechRecognitionState.Listening -> {
                    val partialText = if (state is SpeechRecognitionState.Listening) state.partialText else ""
                    val rms = if (state is SpeechRecognitionState.Listening) state.rms else 1f
                    val dynamicScale = (1f + (rms / 20f)).coerceIn(1f, 1.4f) * pulseScale

                    // Pulsing animated Mic Avatar
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(72.dp)
                            .scale(dynamicScale)
                            .clip(CircleShape)
                            .background(SaraCyan.copy(alpha = 0.2f))
                            .border(2.dp, SaraCyan, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "استماع",
                            tint = SaraCyan,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "سارة تستمع لك الآن... 🇰🇼",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )

                    Text(
                        text = "تكلم بلهجتك الكويتية براحتك يا الغالي",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaraCyan
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Real-time transcribed text preview
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SaraSurfaceDark)
                            .border(1.dp, SaraBorderDark, RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = partialText.ifBlank { "جاري التقاط صوتك..." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (partialText.isNotBlank()) TextWhite else TextMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Button(
                            onClick = { onSendNow(partialText) },
                            enabled = partialText.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SaraCyan,
                                contentColor = SaraDeepObsidian
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("voice_send_button")
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إرسال لسارة", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { onInsertText(partialText) },
                            enabled = partialText.isNotBlank(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite)
                        ) {
                            Icon(imageVector = Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("في المربع")
                        }

                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TextMuted)
                        ) {
                            Text("إلغاء")
                        }
                    }
                }

                is SpeechRecognitionState.Recognized -> {
                    Text(
                        text = "تم التقاط صوتك بنجاح! ✨",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = KuwaitEmerald
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SaraSurfaceDark)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = state.text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextWhite,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onSendNow(state.text) },
                            colors = ButtonDefaults.buttonColors(containerColor = SaraCyan, contentColor = SaraDeepObsidian),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("إرسال فوراً", fontWeight = FontWeight.Bold)
                        }
                        OutlinedButton(
                            onClick = { onInsertText(state.text) },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("تعديل")
                        }
                    }
                }

                is SpeechRecognitionState.Error -> {
                    Text(
                        text = state.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFFF43F5E),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onRetry,
                            colors = ButtonDefaults.buttonColors(containerColor = SaraCyan, contentColor = SaraDeepObsidian),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إعادة المحاولة")
                        }
                        OutlinedButton(
                            onClick = onCancel,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("إغلاق")
                        }
                    }
                }

                is SpeechRecognitionState.Idle -> {}
            }
        }
    }
}



@Composable
private fun ChatInputBar(
    text: String,
    onTextChange: (String) -> Unit,
    isGenerating: Boolean,
    isListening: Boolean,
    hasActiveDocument: Boolean = false,
    hasPendingAttachment: Boolean = false,
    onSend: () -> Unit,
    onMicClick: () -> Unit,
    onPickPhoto: () -> Unit,
    onPickDocument: () -> Unit
) {
    Surface(
        color = SaraSurfaceDark,
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .imePadding()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onPickPhoto,
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = "إرفاق صورة",
                    tint = SaraCyan
                )
            }

            IconButton(
                onClick = onPickDocument,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(if (hasActiveDocument) KuwaitGold.copy(alpha = 0.2f) else Color.Transparent)
                    .testTag("chat_pick_document_button")
            ) {
                Icon(
                    imageVector = if (hasActiveDocument) Icons.Default.Description else Icons.Default.AttachFile,
                    contentDescription = "إرفاق أو اختيار مستند مرجعي",
                    tint = if (hasActiveDocument) KuwaitGold else com.example.ui.theme.SaraOrange
                )
            }

            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                placeholder = {
                    Text(
                        text = if (hasActiveDocument) "اسأل سارة حول المستند المرجعي..." else "اسأل سارة أو اضغط المايك...",
                        color = if (hasActiveDocument) KuwaitGold.copy(alpha = 0.8f) else TextMuted,
                        style = MaterialTheme.typography.bodyMedium
                    )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = SaraSurfaceElevated,
                    unfocusedContainerColor = SaraSurfaceElevated,
                    focusedBorderColor = SaraCyan,
                    unfocusedBorderColor = SaraBorderDark,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                maxLines = 4
            )

            Spacer(modifier = Modifier.width(6.dp))

            // Dedicated Voice Input (STT) Button
            IconButton(
                onClick = onMicClick,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (isListening) Color(0xFF059669) else SaraSurfaceElevated)
                    .border(
                        1.5.dp,
                        if (isListening) KuwaitEmerald else SaraCyan.copy(alpha = 0.5f),
                        CircleShape
                    )
                    .testTag("mic_button")
            ) {
                Icon(
                    imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = "التحدث صوتياً مع سارة",
                    tint = if (isListening) Color.White else SaraCyan,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Send Button
            IconButton(
                onClick = onSend,
                enabled = !isGenerating && (text.isNotBlank() || hasPendingAttachment),
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if ((text.isNotBlank() || hasPendingAttachment) && !isGenerating) SaraCyan else SaraBorderDark)
                    .testTag("send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "إرسال",
                    tint = if ((text.isNotBlank() || hasPendingAttachment) && !isGenerating) SaraDeepObsidian else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("SARA AI", text)
    clipboard.setPrimaryClip(clip)
}

private fun uriToBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.isMutableRequired = true
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (_: Exception) {
        null
    }
}

private fun readTextFromUri(context: Context, uri: Uri): Pair<String, String> {
    return try {
        val fileName = uri.lastPathSegment ?: "document.txt"
        val inputStream = context.contentResolver.openInputStream(uri)
        val reader = BufferedReader(InputStreamReader(inputStream))
        val content = reader.readText()
        reader.close()
        Pair(fileName, content)
    } catch (_: Exception) {
        Pair("مستند", "تعذر استخراج النص الكامل للمستند.")
    }
}
