package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memory
import com.example.data.model.SaraVoiceMode
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

/**
 * Persistent settings drawer content for SARA AI:
 * 1. Toggle between distinct SARA AI voice modes (with audio preview).
 * 2. Manage privacy settings for Firestore persistent memory (toggle storage, clear all memories, delete individual facts).
 */
@Composable
fun SettingsDrawerContent(
    currentVoiceMode: SaraVoiceMode,
    memoryPrivacyEnabled: Boolean,
    memories: List<Memory>,
    onSelectVoiceMode: (SaraVoiceMode) -> Unit,
    onPreviewVoice: (SaraVoiceMode) -> Unit,
    onToggleMemoryPrivacy: () -> Unit,
    onClearAllMemories: () -> Unit,
    onDeleteSingleMemory: (String) -> Unit,
    onCloseDrawer: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showConfirmClearDialog by remember { mutableStateOf(false) }
    var showMemoriesList by remember { mutableStateOf(false) }

    Surface(
        color = SaraSurfaceDark,
        modifier = modifier
            .fillMaxHeight()
            .width(340.dp)
            .testTag("settings_drawer")
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 24.dp)
        ) {
            // Drawer Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaraDeepObsidian)
                    .border(width = 1.dp, color = SaraBorderDark)
                    .padding(horizontal = 16.dp, vertical = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SaraCyan.copy(alpha = 0.15f))
                                .border(1.5.dp, SaraCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = null,
                                tint = SaraCyan,
                                modifier = Modifier.size(22.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "إعدادات سارة الذكية",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Text(
                                text = "أنماط الصوت والخصوصية السحابية 🇰🇼",
                                style = MaterialTheme.typography.labelSmall,
                                color = KuwaitGold
                            )
                        }
                    }

                    IconButton(
                        onClick = onCloseDrawer,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("close_drawer_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق الإعدادات",
                            tint = TextGray
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Section 1: SARA Voice Modes
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RecordVoiceOver,
                        contentDescription = null,
                        tint = SaraCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "أنماط ونبرات صوت سارة",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Text(
                    text = "اختر النبرة التي تفضلها في الحديث والقراءة الصوتية والردود:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // 4 Voice Mode Selection Cards
                SaraVoiceMode.values().forEach { mode ->
                    val isSelected = currentVoiceMode == mode
                    VoiceModeCard(
                        mode = mode,
                        isSelected = isSelected,
                        onSelect = { onSelectVoiceMode(mode) },
                        onPreview = { onPreviewVoice(mode) }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(
                color = SaraBorderDark,
                thickness = 1.dp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Section 2: Firestore Memory Privacy Settings
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = KuwaitGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "خصوصية ذاكرة الجهاز",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Text(
                    text = "تحكم في كيفية حفظ واسترجاع معلوماتك وتفضيلاتك الشخصية في ذاكرة الجهاز المحلية:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // Memory Privacy Toggle Switch Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SaraSurfaceElevated)
                        .border(
                            1.dp,
                            if (memoryPrivacyEnabled) KuwaitEmerald.copy(alpha = 0.5f) else Color(0xFFF43F5E).copy(alpha = 0.5f),
                            RoundedCornerShape(14.dp)
                        )
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "حفظ الذاكرة التلقائي",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (memoryPrivacyEnabled) KuwaitEmerald.copy(alpha = 0.2f)
                                            else Color(0xFFF43F5E).copy(alpha = 0.2f)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (memoryPrivacyEnabled) "نشط" else "متوقف",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (memoryPrivacyEnabled) KuwaitEmerald else Color(0xFFF43F5E),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (memoryPrivacyEnabled)
                                    "سارة تحفظ تفضيلاتك وروتينك في السحابة لتخصيص ردودها لك تلقائياً."
                                else
                                    "وضع الخصوصية التامة: لن يتم حفظ أي معلومات جديدة على الجهاز.",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextGray
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Switch(
                            checked = memoryPrivacyEnabled,
                            onCheckedChange = { onToggleMemoryPrivacy() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SaraDeepObsidian,
                                checkedTrackColor = KuwaitEmerald,
                                uncheckedThumbColor = TextGray,
                                uncheckedTrackColor = SaraSurfaceDark
                            ),
                            modifier = Modifier.testTag("memory_privacy_toggle")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Memory Stats & Expandable List
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SaraSurfaceElevated)
                        .border(1.dp, SaraBorderDark, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = null,
                                    tint = KuwaitEmerald,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "الذكريات المحفوظة: ${memories.size}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                            }

                            if (memories.isNotEmpty()) {
                                TextButton(
                                    onClick = { showMemoriesList = !showMemoriesList },
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(
                                        text = if (showMemoriesList) "إخفاء التفاصيل" else "عرض الذكريات",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SaraCyan
                                    )
                                }
                            }
                        }

                        AnimatedVisibility(visible = showMemoriesList && memories.isNotEmpty()) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                memories.take(6).forEach { mem ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(SaraSurfaceDark)
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = mem.title,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = KuwaitGold
                                            )
                                            Text(
                                                text = mem.content.take(60),
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextGray
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteSingleMemory(mem.id) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "حذف هذه الذكرى",
                                                tint = TextMuted,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Clear All Memories Button (Privacy Reset)
                OutlinedButton(
                    onClick = { showConfirmClearDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("clear_all_memories_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFFF43F5E)
                    ),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFF43F5E).copy(alpha = 0.5f))
                    )
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "مسح سجل الذاكرة بالكامل من السحابة",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "بياناتك مشفرة ومحمية بـ قفل جهازك؛ نسخ بيانات التطبيق احتياطياً مسؤوليتك.",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }

    // Confirmation Alert Dialog for Clearing All Memories
    if (showConfirmClearDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmClearDialog = false },
            containerColor = SaraSurfaceElevated,
            title = {
                Text(
                    text = "مسح كافة ذكريات سارة؟",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF43F5E)
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في مسح كافة الذكريات والمعلومات الشخصية المحفوظة في ذاكرة الجهاز؟ لن تتمكن سارة من تذكر أي تفضيلات سابقة.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextWhite
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmClearDialog = false
                        onClearAllMemories()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE11D48),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("confirm_clear_memories_button")
                ) {
                    Text("نعم، امسح الذكريات", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showConfirmClearDialog = false }
                ) {
                    Text("إلغاء", color = TextGray)
                }
            }
        )
    }
}

/**
 * Individual voice mode selectable card with preview button
 */
@Composable
private fun VoiceModeCard(
    mode: SaraVoiceMode,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onPreview: () -> Unit
) {
    val borderColor = if (isSelected) SaraCyan else SaraBorderDark
    val bgColor = if (isSelected) SaraSurfaceElevated else SaraSurfaceElevated.copy(alpha = 0.5f)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(bgColor)
            .border(1.5.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable(onClick = onSelect)
            .padding(12.dp)
            .testTag("voice_mode_${mode.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) SaraCyan else SaraSurfaceDark)
                            .border(1.dp, if (isSelected) SaraCyan else TextMuted, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = SaraDeepObsidian,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = mode.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) TextWhite else TextGray
                        )
                        Text(
                            text = mode.subtitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) SaraCyan else TextMuted
                        )
                    }
                }

                // Voice Preview Button
                IconButton(
                    onClick = onPreview,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(SaraSurfaceDark)
                        .testTag("preview_voice_${mode.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "تجربة صوت: ${mode.title}",
                        tint = if (isSelected) KuwaitEmerald else TextGray,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = mode.description,
                style = MaterialTheme.typography.labelSmall,
                color = TextGray,
                lineHeight = 16.sp,
                modifier = Modifier.padding(start = 34.dp)
            )
        }
    }
}
