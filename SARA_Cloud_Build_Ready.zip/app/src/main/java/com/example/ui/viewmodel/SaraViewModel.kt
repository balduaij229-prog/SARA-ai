package com.example.ui.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ai.SaraAiService
import com.example.data.model.Conversation
import com.example.data.model.LearnedDocument
import com.example.data.model.Memory
import com.example.data.model.Message
import com.example.data.model.SaraVoiceMode
import com.example.data.model.UserProfile
import com.example.data.repository.SaraRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import com.example.util.MemoryDecision
import com.example.util.SaraMemoryEngine
import kotlinx.coroutines.launch

private const val TAG = "SaraViewModel"

class SaraViewModel(
    private val repository: SaraRepository,
    private val aiService: SaraAiService,
    private val currentUserId: String,
    userDisplayName: String = "صديق سارة",
    userEmail: String? = null
) : ViewModel() {

    private val _userProfile = MutableStateFlow(
        UserProfile(id = currentUserId, userId = currentUserId, displayName = userDisplayName, email = userEmail)
    )
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _voiceMode = MutableStateFlow(SaraVoiceMode.FRIENDLY_KUWAITI)
    val voiceMode: StateFlow<SaraVoiceMode> = _voiceMode.asStateFlow()

    private val _memoryPrivacyEnabled = MutableStateFlow(true)
    val memoryPrivacyEnabled: StateFlow<Boolean> = _memoryPrivacyEnabled.asStateFlow()

    val conversations: StateFlow<List<Conversation>> = repository.observeConversations()
        .catch { e ->
            Log.e(TAG, "Error observing conversations", e)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _currentConversationId = MutableStateFlow<String?>(null)
    val currentConversationId: StateFlow<String?> = _currentConversationId.asStateFlow()

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<Message>> = _currentConversationId
        .flatMapLatest { convId ->
            if (convId.isNullOrBlank()) {
                flowOf(emptyList())
            } else {
                repository.observeMessages(convId)
            }
        }
        .catch { e ->
            Log.e(TAG, "Error observing messages", e)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val memories: StateFlow<List<Memory>> = repository.observeMemories()
        .catch { e ->
            Log.e(TAG, "Error observing memories", e)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    val documents: StateFlow<List<LearnedDocument>> = repository.observeDocuments()
        .catch { e ->
            Log.e(TAG, "Error observing documents", e)
            emit(emptyList())
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _streamingResponse = MutableStateFlow("")
    val streamingResponse: StateFlow<String> = _streamingResponse.asStateFlow()

    private val _attachedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val attachedImageBitmap: StateFlow<Bitmap?> = _attachedImageBitmap.asStateFlow()

    private val _attachedFileName = MutableStateFlow<String?>(null)
    val attachedFileName: StateFlow<String?> = _attachedFileName.asStateFlow()

    private val _attachedFileContent = MutableStateFlow<String?>(null)
    val attachedFileContent: StateFlow<String?> = _attachedFileContent.asStateFlow()

    private val _infoMessage = MutableStateFlow<String?>(null)
    val infoMessage: StateFlow<String?> = _infoMessage.asStateFlow()

    private val _isAnalyzingDoc = MutableStateFlow(false)
    val isAnalyzingDoc: StateFlow<Boolean> = _isAnalyzingDoc.asStateFlow()

    private val _autoSpeakEnabled = MutableStateFlow(false)
    val autoSpeakEnabled: StateFlow<Boolean> = _autoSpeakEnabled.asStateFlow()

    private val _selectedReferenceDocument = MutableStateFlow<LearnedDocument?>(null)
    val selectedReferenceDocument: StateFlow<LearnedDocument?> = _selectedReferenceDocument.asStateFlow()

    fun selectReferenceDocument(doc: LearnedDocument?) {
        _selectedReferenceDocument.value = doc
        if (doc != null) {
            _infoMessage.value = "تم تحديد مرجع الإجابة: ${doc.title} 📄"
        }
    }

    private val _lastGeneratedAiResponse = MutableSharedFlow<String>(extraBufferCapacity = 1)
    val lastGeneratedAiResponse: SharedFlow<String> = _lastGeneratedAiResponse.asSharedFlow()

    fun toggleAutoSpeak() {
        _autoSpeakEnabled.value = !_autoSpeakEnabled.value
    }

    fun setAutoSpeak(enabled: Boolean) {
        _autoSpeakEnabled.value = enabled
    }

    init {
        viewModelScope.launch {
            val result = repository.getOrCreateProfile(userDisplayName, userEmail)
            result.onSuccess { profile ->
                _userProfile.value = profile
                _voiceMode.value = SaraVoiceMode.fromId(profile.voiceMode)
                _memoryPrivacyEnabled.value = profile.memoryPrivacyEnabled
            }
        }
    }

    fun selectConversation(id: String) {
        _currentConversationId.value = id
    }

    fun createNewConversation(title: String = "محادثة جديدة") {
        viewModelScope.launch {
            val res = repository.createConversation(title)
            res.onSuccess { newId ->
                _currentConversationId.value = newId
            }
        }
    }

    fun deleteConversation(id: String) {
        viewModelScope.launch {
            repository.deleteConversation(id)
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
            }
        }
    }

    fun attachImage(bitmap: Bitmap) {
        _attachedImageBitmap.value = bitmap
        _attachedFileName.value = "صورة مرفقة"
        _attachedFileContent.value = null
    }

    fun attachDocument(name: String, content: String) {
        _attachedFileName.value = name
        _attachedFileContent.value = content
        _attachedImageBitmap.value = null
    }

    fun clearAttachment() {
        _attachedImageBitmap.value = null
        _attachedFileName.value = null
        _attachedFileContent.value = null
    }

    fun clearInfoMessage() {
        _infoMessage.value = null
    }

    fun sendMessage(prompt: String) {
        if (prompt.isBlank() && _attachedImageBitmap.value == null && _attachedFileContent.value == null) return
        if (_isGenerating.value) return

        viewModelScope.launch {
            // Ensure we have an active conversation
            var convId = _currentConversationId.value
            if (convId.isNullOrBlank()) {
                val titleSnippet = prompt.take(30).ifBlank { "محادثة مع سارة" }
                val newConvResult = repository.createConversation(titleSnippet)
                convId = newConvResult.getOrNull()
                if (convId == null) {
                    _infoMessage.value = "تعذر إنشاء محادثة جديدة"
                    return@launch
                }
                _currentConversationId.value = convId
            }

            val img = _attachedImageBitmap.value
            val docName = _attachedFileName.value
            val docContent = _attachedFileContent.value

            val attachType = when {
                img != null -> "image"
                docContent != null -> "document"
                else -> "none"
            }

            val userTextWithDoc = if (!docContent.isNullOrBlank()) {
                "$prompt\n\n[محتوى المستند: $docName]\n$docContent"
            } else {
                prompt
            }

            // Save user message
            repository.addMessage(
                conversationId = convId,
                role = "user",
                content = prompt.ifBlank { "أرسل ملف: $docName" },
                attachmentType = attachType,
                attachmentName = docName
            )

            // Clear attachments from input
            clearAttachment()

            // Prepare AI streaming
            _isGenerating.value = true
            _streamingResponse.value = ""

            val history = messages.value
            val currentMems = memories.value
            val currentDocs = documents.value
            val dialect = _userProfile.value.preferredDialect

            val accumulated = StringBuilder()

            try {
                aiService.streamResponse(
                    userPrompt = userTextWithDoc,
                    conversationHistory = history,
                    memories = currentMems,
                    documents = currentDocs,
                    preferredDialect = dialect,
                    voiceMode = _voiceMode.value,
                    referenceDocument = _selectedReferenceDocument.value,
                    imageBitmap = img
                ).collect { chunk ->
                    accumulated.append(chunk)
                    _streamingResponse.value = accumulated.toString()
                }

                val finalAiResponse = accumulated.toString()
                if (finalAiResponse.isNotBlank()) {
                    repository.addMessage(
                        conversationId = convId,
                        role = "model",
                        content = finalAiResponse
                    )
                    _lastGeneratedAiResponse.tryEmit(finalAiResponse)
                }

                // Auto-detect if user taught SARA something or stated a preference (only when memory privacy allows)
                if (_memoryPrivacyEnabled.value) {
                    checkAndLearnAutomatically(prompt, finalAiResponse)
                }

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI Generation failed", e)
                val errMsg = "يا هلا.. واجهت مشكلة في الاتصال أو الإجابة: ${e.localizedMessage ?: "حاول مرة ثانية"}"
                repository.addMessage(
                    conversationId = convId,
                    role = "model",
                    content = errMsg
                )
                _infoMessage.value = e.localizedMessage ?: "فشل في توليد الرد"
            } finally {
                _isGenerating.value = false
                _streamingResponse.value = ""
            }
        }
    }

    private fun checkAndLearnAutomatically(userPrompt: String, aiResponse: String) {
        viewModelScope.launch {
            try {
                val currentMemories = memories.value
                when (val decision = SaraMemoryEngine.analyzeAndDecide(userPrompt, currentMemories)) {
                    is MemoryDecision.Create -> {
                        val res = repository.addMemory(
                            title = decision.title,
                            content = decision.content,
                            category = decision.category,
                            importance = decision.importance
                        )
                        res.onSuccess {
                            _infoMessage.value = "سارة حفظت في ذاكرتها: ${decision.title} 🧠"
                        }
                    }
                    is MemoryDecision.Update -> {
                        val res = repository.updateMemory(
                            memoryId = decision.existingMemoryId,
                            title = decision.title,
                            content = decision.content,
                            category = decision.category,
                            importance = decision.importance
                        )
                        res.onSuccess {
                            _infoMessage.value = "سارة حدّثت معلوماتها: ${decision.title} ✨"
                        }
                    }
                    is MemoryDecision.NoChange -> {
                        // Already known or duplicate, skip writing to Firestore
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Automatic memory learning skipped: ${e.message}")
            }
        }
    }

    fun addManualMemory(title: String, content: String, category: String = "general", importance: Int = 3) {
        viewModelScope.launch {
            val res = repository.addMemory(title, content, category, importance)
            res.onSuccess {
                _infoMessage.value = "تمت إضافة الذاكرة بنجاح إلى ذكاء سارة ✨"
            }.onFailure { err ->
                _infoMessage.value = "فشل في حفظ الذاكرة: ${err.localizedMessage}"
            }
        }
    }

    fun updateMemory(
        memoryId: String,
        title: String,
        content: String,
        category: String = "general",
        importance: Int = 3
    ) {
        viewModelScope.launch {
            val res = repository.updateMemory(memoryId, title, content, category, importance)
            res.onSuccess {
                _infoMessage.value = "تم تحديث المعلومة بنجاح في ذاكرة سارة ✨"
            }.onFailure { err ->
                _infoMessage.value = "فشل في تحديث الذاكرة: ${err.localizedMessage}"
            }
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            repository.deleteMemory(memoryId)
            _infoMessage.value = "تم مسح الذاكرة"
        }
    }

    fun uploadAndLearnDocument(
        fileName: String,
        content: String,
        bitmap: Bitmap?,
        fileType: String = "text",
        fileSizeBytes: Long = 0L,
        pageCount: Int = 1
    ) {
        viewModelScope.launch {
            _isAnalyzingDoc.value = true
            try {
                val analysis = aiService.analyzeDocument(fileName, content, bitmap)
                val res = repository.addDocument(
                    title = analysis.title,
                    summary = analysis.summary,
                    extractedContent = analysis.keyPoints,
                    fileType = fileType,
                    fileSizeBytes = fileSizeBytes,
                    pageCount = pageCount
                )
                res.getOrThrow()

                // Also create an associated memory item so SARA references it if memory privacy is enabled
                if (_memoryPrivacyEnabled.value) {
                    repository.addMemory(
                        title = "مستند: ${analysis.title.take(30)}",
                        content = "${analysis.summary}\n${analysis.keyPoints.take(200)}",
                        category = "work",
                        importance = 4
                    )
                }
                _infoMessage.value = "تم استيعاب وحفظ المستند في ذاكرة الجهاز بنجاح 📄✨"
            } catch (e: Exception) {
                Log.e(TAG, "Failed to teach SARA from document", e)
                _infoMessage.value = "فشل تحليل المستند: ${e.localizedMessage}"
            } finally {
                _isAnalyzingDoc.value = false
            }
        }
    }

    fun teachSaraFromDocument(fileName: String, content: String, bitmap: Bitmap?) {
        val fileType = if (fileName.endsWith(".pdf", ignoreCase = true)) "pdf" else if (bitmap != null) "image" else "text"
        uploadAndLearnDocument(fileName, content, bitmap, fileType = fileType)
    }

    fun deleteDocument(docId: String) {
        viewModelScope.launch {
            repository.deleteDocument(docId)
            if (_selectedReferenceDocument.value?.id == docId) {
                _selectedReferenceDocument.value = null
            }
            _infoMessage.value = "تم مسح المستند من المعرفة"
        }
    }

    fun updateDialect(dialect: String) {
        viewModelScope.launch {
            val res = repository.updateDialect(dialect)
            res.onSuccess {
                _userProfile.value = _userProfile.value.copy(preferredDialect = dialect)
                val label = if (dialect == "kuwaiti") "اللهجة الكويتية الأصيلة" else "العربية الفصحى"
                _infoMessage.value = "تم تغيير أسلوب سارة إلى: $label"
            }
        }
    }

    fun setVoiceMode(mode: SaraVoiceMode) {
        _voiceMode.value = mode
        _userProfile.value = _userProfile.value.copy(voiceMode = mode.id)
        viewModelScope.launch {
            repository.updateVoiceMode(mode.id)
            _infoMessage.value = "تم تفعيل نمط الصوت: ${mode.title}"
        }
    }

    fun toggleMemoryPrivacy() {
        val newState = !_memoryPrivacyEnabled.value
        setMemoryPrivacy(newState)
    }

    fun setMemoryPrivacy(enabled: Boolean) {
        _memoryPrivacyEnabled.value = enabled
        _userProfile.value = _userProfile.value.copy(memoryPrivacyEnabled = enabled)
        viewModelScope.launch {
            repository.updateMemoryPrivacy(enabled)
            _infoMessage.value = if (enabled) "تم تفعيل حفظ الذكريات في السحابة 💾" else "تم إيقاف حفظ الذكريات (وضع الخصوصية التامة) 🔒"
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            val res = repository.clearAllMemories()
            res.onSuccess {
                _infoMessage.value = "تم مسح كافة الذكريات المحفوظة في السحابة بنجاح 🧹"
            }.onFailure { err ->
                _infoMessage.value = "تعذر مسح الذكريات: ${err.localizedMessage}"
            }
        }
    }
}
