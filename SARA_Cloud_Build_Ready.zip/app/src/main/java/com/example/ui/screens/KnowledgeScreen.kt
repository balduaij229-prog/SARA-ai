package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearnedDocument
import com.example.ui.components.DocumentContentDialog
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.SaraViewModel
import com.example.util.DocumentExtractor

@Composable
fun KnowledgeScreen(
    viewModel: SaraViewModel,
    onAskAboutDocument: (LearnedDocument) -> Unit = {}
) {
    val context = LocalContext.current
    val documents by viewModel.documents.collectAsState()
    val isAnalyzing by viewModel.isAnalyzingDoc.collectAsState()
    var viewingDoc by remember { mutableStateOf<LearnedDocument?>(null) }

    // Photo picker to teach SARA from images (menus, receipts, study diagrams, invoices)
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let {
            val bitmap = uriToBitmap(context, it)
            val name = it.lastPathSegment ?: "صورة_معرفية.jpg"
            if (bitmap != null) {
                viewModel.uploadAndLearnDocument(
                    fileName = name,
                    content = "",
                    bitmap = bitmap,
                    fileType = "image"
                )
            }
        }
    }

    // Document picker to upload PDF or Text files to Firestore
    val documentPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            val extracted = DocumentExtractor.extract(context, it)
            viewModel.uploadAndLearnDocument(
                fileName = extracted.fileName,
                content = extracted.textContent,
                bitmap = extracted.previewBitmap,
                fileType = extracted.fileType,
                fileSizeBytes = extracted.fileSizeBytes,
                pageCount = extracted.pageCount
            )
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SaraDeepObsidian)
    ) {
        // Top Header
        Surface(
            color = SaraSurfaceDark,
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = KuwaitEmerald,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "المستندات والمعرفة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SaraSurfaceElevated,
                                contentColor = SaraCyan
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            enabled = !isAnalyzing
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("صورة", style = MaterialTheme.typography.labelMedium)
                        }

                        Button(
                            onClick = {
                                documentPickerLauncher.launch(
                                    arrayOf("application/pdf", "text/*", "*/*")
                                )
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = KuwaitEmerald,
                                contentColor = SaraDeepObsidian
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            enabled = !isAnalyzing,
                            modifier = Modifier.testTag("upload_document_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.UploadFile,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("رفع PDF / نص", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "ارفع ملفات PDF أو نصوص إلى Firestore لتستند إليها سارة في إجاباتها الذكية بدقة",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )
            }
        }

        // Analyzing State Banner
        if (isAnalyzing) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaraSurfaceElevated)
                    .border(1.dp, KuwaitEmerald.copy(alpha = 0.5f))
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = KuwaitEmerald,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "سارة تقرأ وتحلل المستند وترفعه إلى Firestore...",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "جاري استخراج النقاط الهامة وحفظها كمرجع للإجابات السياقية",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGray
                    )
                }
            }
        }

        // Documents List or Empty State
        if (documents.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Description,
                        contentDescription = null,
                        tint = KuwaitEmerald.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "لا توجد مستندات بعد في السحابة",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ارفع ملفات العمل (PDF، TXT)، الملاحظات، أو العقود لتقرأها سارة وتخزنها في Firestore للرجوع إليها في أي وقت!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            documentPickerLauncher.launch(arrayOf("application/pdf", "text/*", "*/*"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = KuwaitEmerald, contentColor = SaraDeepObsidian),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("رفع أول مستند الآن (PDF / نص)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(documents, key = { it.id }) { doc ->
                    DocumentCard(
                        doc = doc,
                        onDelete = { viewModel.deleteDocument(doc.id) },
                        onAskAboutDoc = { onAskAboutDocument(doc) },
                        onViewContent = { viewingDoc = doc }
                    )
                }
            }
        }
    }

    // Document Content Viewer Dialog
    DocumentContentDialog(
        doc = viewingDoc,
        onDismiss = { viewingDoc = null },
        onAskAboutDoc = { doc ->
            viewingDoc = null
            onAskAboutDocument(doc)
        }
    )
}

@Composable
private fun DocumentCard(
    doc: LearnedDocument,
    onDelete: () -> Unit,
    onAskAboutDoc: () -> Unit,
    onViewContent: () -> Unit
) {
    val isPdf = doc.fileType == "pdf"
    val isImage = doc.fileType == "image"
    val formattedSize = formatFileSize(doc.fileSizeBytes)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SaraSurfaceDark)
            .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
            .clickable(onClick = onViewContent)
            .padding(16.dp)
            .testTag("document_card_${doc.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            isPdf -> Color(0xFFE11D48).copy(alpha = 0.2f)
                            isImage -> SaraCyan.copy(alpha = 0.2f)
                            else -> KuwaitEmerald.copy(alpha = 0.2f)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        isPdf -> Icons.Default.PictureAsPdf
                        isImage -> Icons.Default.Image
                        else -> Icons.Default.Description
                    },
                    contentDescription = null,
                    tint = when {
                        isPdf -> Color(0xFFF43F5E)
                        isImage -> SaraCyan
                        else -> KuwaitEmerald
                    },
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = doc.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite,
                    maxLines = 1
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                when {
                                    isPdf -> Color(0xFFE11D48).copy(alpha = 0.25f)
                                    isImage -> SaraCyan.copy(alpha = 0.25f)
                                    else -> KuwaitEmerald.copy(alpha = 0.25f)
                                }
                            )
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = when {
                                isPdf -> "PDF"
                                isImage -> "صورة"
                                else -> "نص TXT"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                isPdf -> Color(0xFFF43F5E)
                                isImage -> SaraCyan
                                else -> KuwaitEmerald
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }

                    if (formattedSize.isNotBlank()) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• $formattedSize",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }

                    if (isPdf && doc.pageCount > 0) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${doc.pageCount} ${if (doc.pageCount == 1) "صفحة" else "صفحات"}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(34.dp)
                    .testTag("delete_doc_${doc.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف المستند",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Summary box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(SaraSurfaceElevated)
                .padding(12.dp)
        ) {
            Column {
                Text(
                    text = "خلاصة سارة للذكاء الاصطناعي:",
                    style = MaterialTheme.typography.labelSmall,
                    color = KuwaitGold,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = doc.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextWhite,
                    lineHeight = 22.sp
                )
            }
        }

        if (doc.extractedContent.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "النقاط المستخرجة من الملف:",
                style = MaterialTheme.typography.labelSmall,
                color = TextGray,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = doc.extractedContent.take(240) + if (doc.extractedContent.length > 240) "..." else "",
                style = MaterialTheme.typography.bodySmall,
                color = TextGray,
                lineHeight = 18.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons Row: Ask SARA about this document & View full content
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onAskAboutDoc,
                colors = ButtonDefaults.buttonColors(
                    containerColor = SaraCyan,
                    contentColor = SaraDeepObsidian
                ),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .testTag("ask_about_doc_${doc.id}")
            ) {
                Icon(imageVector = Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("اسأل سارة عن هذا المستند 💬", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = onViewContent,
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                border = ButtonDefaults.outlinedButtonBorder.copy(
                    brush = androidx.compose.ui.graphics.SolidColor(SaraBorderDark)
                ),
                modifier = Modifier.height(38.dp)
            ) {
                Icon(imageVector = Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("التفاصيل", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return ""
    return when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "${bytes / 1024} KB"
        else -> String.format("%.1f MB", bytes / (1024f * 1024f))
    }
}

private fun uriToBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.isMutableRequired = true
            }
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (_: Exception) {
        null
    }
}
