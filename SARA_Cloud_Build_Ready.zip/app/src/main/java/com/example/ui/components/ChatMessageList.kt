package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.Message
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraBubble
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.UserBubble
import com.google.firebase.Timestamp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Main UI component for displaying the chronological conversation history
 * between the user and SARA AI, fetched from Firestore.
 */
@Composable
fun ChatMessageList(
    messages: List<Message>,
    isGenerating: Boolean,
    streamingChunk: String,
    isSpeaking: Boolean,
    currentUtteranceId: String?,
    onSpeakMessage: (Message) -> Unit,
    onStopSpeaking: () -> Unit,
    onSelectSuggestion: (String) -> Unit,
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState()
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Ensure strict chronological ordering by creation timestamp ascending
    val chronologicalMessages = remember(messages) {
        messages.sortedWith(
            compareBy<Message> { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                .thenBy { it.id }
        )
    }

    // Determine whether to show the "Scroll to Bottom" FAB
    val showScrollToBottom by remember {
        derivedStateOf {
            val totalItems = chronologicalMessages.size + if (isGenerating) 1 else 0
            if (totalItems <= 3) {
                false
            } else {
                val lastVisibleItemIndex = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
                lastVisibleItemIndex < totalItems - 2
            }
        }
    }

    // Auto-scroll to latest message when messages change or while streaming
    LaunchedEffect(chronologicalMessages.size, streamingChunk) {
        val totalCount = chronologicalMessages.size + if (isGenerating) 1 else 0
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("chat_messages_list")
    ) {
        if (chronologicalMessages.isEmpty() && !isGenerating) {
            EmptyChatSuggestionsView(onSelectSuggestion = onSelectSuggestion)
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Group messages with chronological date headers
                var previousDateKey = ""

                chronologicalMessages.forEachIndexed { index, msg ->
                    val currentDateKey = getDateKey(msg.createdAt)
                    if (currentDateKey != previousDateKey) {
                        item(key = "header_$currentDateKey") {
                            DateSeparatorChip(dateText = formatDateHeader(msg.createdAt))
                        }
                        previousDateKey = currentDateKey
                    }

                    item(key = msg.id.ifBlank { "msg_${index}_${msg.createdAt?.seconds ?: 0}" }) {
                        val isThisMessageSpeaking = isSpeaking && currentUtteranceId == msg.id
                        val isUser = msg.role == "user"

                        if (isUser) {
                            UserMessageBubble(
                                message = msg,
                                onCopy = {
                                    copyTextToClipboard(context, msg.content)
                                }
                            )
                        } else {
                            SaraAiMessageBubble(
                                message = msg,
                                isSpeaking = isThisMessageSpeaking,
                                onCopy = {
                                    copyTextToClipboard(context, msg.content)
                                },
                                onSpeak = {
                                    if (isThisMessageSpeaking) {
                                        onStopSpeaking()
                                    } else {
                                        onSpeakMessage(msg)
                                    }
                                }
                            )
                        }
                    }
                }

                // Streaming preview bubble during AI generation
                if (isGenerating) {
                    item(key = "streaming_bubble_indicator") {
                        StreamingAiBubble(
                            text = streamingChunk.ifBlank { "سارة تكتب لك الآن..." }
                        )
                    }
                }
            }
        }

        // Floating Scroll-To-Bottom FAB
        AnimatedVisibility(
            visible = showScrollToBottom,
            enter = fadeIn() + scaleIn(),
            exit = fadeOut() + scaleOut(),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        ) {
            FloatingActionButton(
                onClick = {
                    coroutineScope.launch {
                        val totalCount = chronologicalMessages.size + if (isGenerating) 1 else 0
                        if (totalCount > 0) {
                            listState.animateScrollToItem(totalCount - 1)
                        }
                    }
                },
                containerColor = SaraSurfaceElevated,
                contentColor = SaraCyan,
                elevation = FloatingActionButtonDefaults.elevation(6.dp),
                shape = CircleShape,
                modifier = Modifier
                    .size(42.dp)
                    .border(1.dp, SaraCyan.copy(alpha = 0.4f), CircleShape)
                    .testTag("scroll_to_bottom_button")
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "الانتقال لآخر الرسائل",
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

/**
 * User Message Bubble:
 * - End-aligned (RTL natural)
 * - Deep cyan/slate tone (UserBubble)
 * - Rounded with corner tail on the user's side
 * - Displays attachment tags & formatted timestamp
 */
@Composable
fun UserMessageBubble(
    message: Message,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .testTag("message_bubble_user"),
        horizontalArrangement = Arrangement.End
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(0.85f),
            horizontalAlignment = Alignment.End
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 4.dp
                        )
                    )
                    .background(UserBubble)
                    .border(
                        1.dp,
                        SaraCyan.copy(alpha = 0.35f),
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 18.dp,
                            bottomEnd = 4.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Column {
                    // Role badge & icon
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Text(
                            text = "أنت",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaraCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = SaraCyan,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    // Attachment Chip if present
                    if (message.attachmentType == "image") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .padding(bottom = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SaraSurfaceDark.copy(alpha = 0.6f))
                                .border(1.dp, SaraCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = SaraCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "مرفق صورة تم تحليلها",
                                style = MaterialTheme.typography.labelSmall,
                                color = SaraCyan,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    } else if (message.attachmentType == "document") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .padding(bottom = 8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(SaraSurfaceDark.copy(alpha = 0.6f))
                                .border(1.dp, KuwaitGold.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AttachFile,
                                contentDescription = null,
                                tint = KuwaitGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = message.attachmentName ?: "مستند معرفي",
                                style = MaterialTheme.typography.labelSmall,
                                color = KuwaitGold,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // Message Content
                    SelectionContainer {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextWhite,
                            lineHeight = 24.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Timestamp and Copy action
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onCopy,
                            modifier = Modifier
                                .size(24.dp)
                                .testTag("copy_message_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "نسخ نص رسالتك",
                                tint = TextMuted,
                                modifier = Modifier.size(13.dp)
                            )
                        }

                        Text(
                            text = formatMessageTime(message.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextGray.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }
    }
}

/**
 * SARA AI Message Bubble:
 * - Start-aligned (RTL natural)
 * - SARA Avatar with status ring
 * - Rich dark bubble (SaraBubble) with dynamic accent border
 * - Voice speech playback toggle with playing waveform indicator
 * - Copy button
 * - Formatted Arabic timestamp
 */
@Composable
fun SaraAiMessageBubble(
    message: Message,
    isSpeaking: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .testTag("message_bubble_model"),
        horizontalArrangement = Arrangement.Start
    ) {
        // SARA Avatar
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(36.dp)
                .clip(CircleShape)
                .background(SaraSurfaceElevated)
                .border(1.5.dp, if (isSpeaking) KuwaitEmerald else SaraCyan, CircleShape)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_sara_logo),
                contentDescription = "سارة",
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Column(
            modifier = Modifier.fillMaxWidth(0.88f),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .background(SaraBubble)
                    .border(
                        1.dp,
                        if (isSpeaking) KuwaitEmerald.copy(alpha = 0.6f) else SaraBorderDark,
                        RoundedCornerShape(
                            topStart = 18.dp,
                            topEnd = 18.dp,
                            bottomStart = 4.dp,
                            bottomEnd = 18.dp
                        )
                    )
                    .padding(14.dp)
            ) {
                Column {
                    // SARA header tag
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 6.dp)
                    ) {
                        Text(
                            text = "سارة • ذكاء كويتي",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSpeaking) KuwaitEmerald else SaraCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(if (isSpeaking) KuwaitEmerald else SaraCyan)
                        )
                        if (isSpeaking) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تتحدث...",
                                style = MaterialTheme.typography.labelSmall,
                                color = KuwaitEmerald
                            )
                        }
                    }

                    // Message text
                    SelectionContainer {
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyLarge,
                            color = TextWhite,
                            lineHeight = 25.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Bottom actions: TTS speech, Copy, Timestamp
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // TTS Play/Stop Button
                            IconButton(
                                onClick = onSpeak,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (isSpeaking) KuwaitEmerald.copy(alpha = 0.15f)
                                        else SaraSurfaceElevated
                                    )
                                    .testTag("message_speak_button")
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                                    contentDescription = if (isSpeaking) "إيقاف الصوت" else "استماع لصوت سارة",
                                    tint = if (isSpeaking) KuwaitEmerald else SaraCyan,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            // Copy message button
                            IconButton(
                                onClick = onCopy,
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(SaraSurfaceElevated)
                                    .testTag("message_copy_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ContentCopy,
                                    contentDescription = "نسخ الرد",
                                    tint = TextGray,
                                    modifier = Modifier.size(15.dp)
                                )
                            }
                        }

                        Text(
                            text = formatMessageTime(message.createdAt),
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }
                }
            }
        }
    }
}

/**
 * Streaming indicator bubble shown at the bottom while Gemini is actively streaming response
 */
@Composable
fun StreamingAiBubble(
    text: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(top = 2.dp)
                .size(36.dp)
                .clip(CircleShape)
                .background(SaraSurfaceElevated)
                .border(1.5.dp, SaraCyan, CircleShape)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_sara_logo),
                contentDescription = "سارة",
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth(0.88f)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = 4.dp,
                        bottomEnd = 18.dp
                    )
                )
                .background(SaraBubble)
                .border(
                    1.dp,
                    SaraCyan.copy(alpha = 0.5f),
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = 4.dp,
                        bottomEnd = 18.dp
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Text(
                        text = "سارة تكتب لك الآن...",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaraCyan,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    CircularProgressIndicator(
                        modifier = Modifier.size(12.dp),
                        color = SaraCyan,
                        strokeWidth = 2.dp
                    )
                }

                Text(
                    text = text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextWhite,
                    lineHeight = 24.sp
                )
            }
        }
    }
}

/**
 * Date separator chip (e.g. "اليوم", "أمس", "الأربعاء، 28 أكتوبر")
 */
@Composable
fun DateSeparatorChip(
    dateText: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(SaraSurfaceElevated)
                .border(1.dp, SaraBorderDark.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            Text(
                text = dateText,
                style = MaterialTheme.typography.labelSmall,
                color = TextGray,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * Empty Chat Suggestions View for quick Kuwaiti queries
 */
@Composable
fun EmptyChatSuggestionsView(
    onSelectSuggestion: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "هلا وغلا! شلون أقدر أساعدك اليوم؟",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextWhite,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "أنا سارة، أساعدك في مهامك، أتكلم معك صوتياً، أحفظ تفضيلاتك، وأتعلم من مستنداتك بلهجتنا الكويتية.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextGray,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        val suggestions = listOf(
            "يا هلا بسارة، شنو الأماكن والمقاهي الحلوة الحين بالكويت؟ 🇰🇼",
            "سارة، احفظي في ذاكرتك إني أحب القهوة المقطرة بدون سكر ☕",
            "كتبي لي إيميل رسمي احترافي لمتابعة مشروع عمل 📝",
            "يبيله خطة لتنظيم وقتي ودوامي هالأسبوع، شرايك؟ 📅"
        )

        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            suggestions.forEach { suggestion ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(SaraSurfaceElevated)
                        .border(1.dp, SaraBorderDark, RoundedCornerShape(14.dp))
                        .clickable { onSelectSuggestion(suggestion) }
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = suggestion,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextWhite
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// Helper Date & Time Formatter Functions
// -------------------------------------------------------------

fun getDateKey(timestamp: Timestamp?): String {
    if (timestamp == null) return "today"
    val sdf = SimpleDateFormat("yyyyMMdd", Locale.US)
    return sdf.format(timestamp.toDate())
}

fun formatDateHeader(timestamp: Timestamp?): String {
    if (timestamp == null) return "اليوم"
    val cal = Calendar.getInstance().apply { time = timestamp.toDate() }
    val now = Calendar.getInstance()

    val isToday = cal.get(Calendar.YEAR) == now.get(Calendar.YEAR) &&
            cal.get(Calendar.DAY_OF_YEAR) == now.get(Calendar.DAY_OF_YEAR)
    if (isToday) return "اليوم"

    val yesterday = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    val isYesterday = cal.get(Calendar.YEAR) == yesterday.get(Calendar.YEAR) &&
            cal.get(Calendar.DAY_OF_YEAR) == yesterday.get(Calendar.DAY_OF_YEAR)
    if (isYesterday) return "أمس"

    val sdf = SimpleDateFormat("EEEE، d MMMM", Locale("ar"))
    return sdf.format(timestamp.toDate())
}

fun formatMessageTime(timestamp: Timestamp?): String {
    if (timestamp == null) return "الآن"
    val sdf = SimpleDateFormat("h:mm a", Locale("ar"))
    return sdf.format(timestamp.toDate())
}

private fun copyTextToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("SARA AI", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "تم نسخ النص", Toast.LENGTH_SHORT).show()
}

