package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import com.example.data.model.SaraVoiceMode
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.SaraViewModel

@Composable
fun ProfileScreen(
    viewModel: SaraViewModel
) {

    val userProfile by viewModel.userProfile.collectAsState()
    val conversations by viewModel.conversations.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val documents by viewModel.documents.collectAsState()
    val currentVoiceMode by viewModel.voiceMode.collectAsState()
    val memoryPrivacyEnabled by viewModel.memoryPrivacyEnabled.collectAsState()
    var showConfirmClearDialog by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SaraDeepObsidian)
            .verticalScroll(rememberScrollState())
    ) {
        // Top Header
        Surface(
            color = SaraSurfaceDark,
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 4.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 18.dp)
            ) {
                Text(
                    text = "الإعدادات والملف الشخصي",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Text(
                    text = "تخصيص أسلوب سارة وذاكرتها على هذا الجهاز",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // User Profile Card
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(SaraCyan.copy(alpha = 0.2f))
                        .border(1.5.dp, SaraCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = SaraCyan,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Text(
                        text = userProfile.displayName.ifBlank { "صديق سارة" },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = userProfile.email ?: "حساب Google متصل",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGray
                    )
                }
            }

            // Stats Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    modifier = Modifier.weight(1f),
                    count = conversations.size.toString(),
                    label = "المحادثات",
                    icon = Icons.Default.Forum,
                    tint = SaraCyan
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    count = memories.size.toString(),
                    label = "الذكريات",
                    icon = Icons.Default.Psychology,
                    tint = KuwaitGold
                )
                StatCard(
                    modifier = Modifier.weight(1f),
                    count = documents.size.toString(),
                    label = "المستندات",
                    icon = Icons.Default.Description,
                    tint = KuwaitEmerald
                )
            }

            // Personality / Dialect Setting Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = "أسلوب ولهجة سارة في الردود",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )

                Spacer(modifier = Modifier.height(12.dp))

                DialectOption(
                    title = "🇰🇼 اللهجة الكويتية العفوية (الموصى بها)",
                    subtitle = "يا هلا وغلا، عيوني، ما طلبت شي، حاضر وتدلل، خوش فكرة",
                    selected = userProfile.preferredDialect == "kuwaiti",
                    onClick = { viewModel.updateDialect("kuwaiti") }
                )

                Spacer(modifier = Modifier.height(8.dp))

                DialectOption(
                    title = "📖 اللغة العربية الفصحى المبسطة",
                    subtitle = "أهلاً ومرحباً بك، يسعدني تقديم المساعدة الكاملة لك",
                    selected = userProfile.preferredDialect == "modern_standard",
                    onClick = { viewModel.updateDialect("modern_standard") }
                )
            }

            // Voice & Hands-Free Interaction Settings Card
            val autoSpeakEnabled by viewModel.autoSpeakEnabled.collectAsState()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = null,
                            tint = SaraCyan,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الصوت والتفاعل دون لمس",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    }

                    androidx.compose.material3.Switch(
                        checked = autoSpeakEnabled,
                        onCheckedChange = { viewModel.toggleAutoSpeak() },
                        colors = androidx.compose.material3.SwitchDefaults.colors(
                            checkedThumbColor = SaraDeepObsidian,
                            checkedTrackColor = SaraCyan,
                            uncheckedThumbColor = TextGray,
                            uncheckedTrackColor = SaraSurfaceElevated
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "قراءة ردود سارة تلقائياً بصوت كويتي أصيل وودود بمجرد اكتمال الرد.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = KuwaitEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "نبرة كويتية دافئة ونطق طبيعي للعبارات والمصطلحات المحلية",
                        style = MaterialTheme.typography.labelSmall,
                        color = KuwaitEmerald
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = KuwaitEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تعرف صوتي فوري باللهجة الكويتية (Speech-to-Text: ar-KW)",
                        style = MaterialTheme.typography.labelSmall,
                        color = KuwaitEmerald
                    )
                }
            }

            // SARA Voice Modes Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = SaraCyan,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "نمط ونبرة صوت سارة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                SaraVoiceMode.values().forEach { mode ->
                    val isSelected = currentVoiceMode == mode
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) SaraSurfaceElevated else Color.Transparent)
                            .border(1.dp, if (isSelected) SaraCyan else SaraBorderDark, RoundedCornerShape(12.dp))
                            .clickable { viewModel.setVoiceMode(mode) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSelected,
                            onClick = { viewModel.setVoiceMode(mode) },
                            colors = RadioButtonDefaults.colors(
                                selectedColor = SaraCyan,
                                unselectedColor = TextMuted
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = mode.title,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) TextWhite else TextGray
                            )
                            Text(
                                text = mode.subtitle,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                    }
                }
            }

            // Firestore Memory Privacy Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = KuwaitGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "خصوصية الذاكرة في Firestore",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                    }

                    Switch(
                        checked = memoryPrivacyEnabled,
                        onCheckedChange = { viewModel.toggleMemoryPrivacy() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SaraDeepObsidian,
                            checkedTrackColor = KuwaitEmerald,
                            uncheckedThumbColor = TextGray,
                            uncheckedTrackColor = SaraSurfaceElevated
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (memoryPrivacyEnabled)
                        "حفظ الذكريات التلقائي نشط: تحفظ سارة اهتماماتك وتفاصيلك في السحابة لتقديم ردود مخصصة."
                    else
                        "وضع الخصوصية التامة: تم إيقاف حفظ وتخزين الذكريات الجديدة في قاعدة بيانات Firestore.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = { showConfirmClearDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF43F5E)),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(Color(0xFFF43F5E).copy(alpha = 0.5f))
                    )
                ) {
                    Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("مسح سجل الذاكرة بالكامل من السحابة", fontWeight = FontWeight.Bold)
                }
            }

            // Security & Privacy Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(SaraSurfaceDark)
                    .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = KuwaitEmerald,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الخصوصية والتخزين المحلي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                SecurityBullet("📱 المحادثات والذاكرة والمستندات تُحفظ على هذا الجهاز")
                SecurityBullet("🔒 بدون حساب أو تسجيل دخول؛ يُفضّل قفل الهاتف لحماية المعلومات")
                SecurityBullet("🌐 الردود الذكية تتطلب إنترنت؛ يُرسل محتوى الرسائل إلى خدمة الذكاء الاصطناعي")
                SecurityBullet("⚠️ بيانات Firestore القديمة لا تُنقل تلقائياً إلى الجهاز")
            }

            Spacer(modifier = Modifier.height(8.dp))

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showConfirmClearDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmClearDialog = false },
            containerColor = SaraSurfaceElevated,
            title = {
                Text(
                    text = "مسح كافة ذكريات سارة؟",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFF43F5E)
                )
            },
            text = {
                Text(
                    text = "هل أنت متأكد من رغبتك في مسح كافة الذكريات والمعلومات الشخصية المحفوظة في ذاكرة سارة المحلية؟ لن تتمكن سارة من تذكر أي تفضيلات سابقة.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextWhite
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConfirmClearDialog = false
                        viewModel.clearAllMemories()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFE11D48),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("نعم، امسح الذكريات", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showConfirmClearDialog = false }
                ) {
                    Text("إلغاء", color = TextGray)
                }
            }
        )
    }
}

@Composable
private fun StatCard(
    modifier: Modifier,
    count: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(SaraSurfaceDark)
            .border(1.dp, SaraBorderDark, RoundedCornerShape(14.dp))
            .padding(vertical = 12.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = count,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextGray
            )
        }
    }
}

@Composable
private fun DialectOption(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) SaraSurfaceElevated else Color.Transparent)
            .border(1.dp, if (selected) SaraCyan else SaraBorderDark, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = selected,
            onClick = onClick,
            colors = RadioButtonDefaults.colors(
                selectedColor = SaraCyan,
                unselectedColor = TextMuted
            )
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = if (selected) TextWhite else TextGray
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
private fun SecurityBullet(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.bodySmall,
            color = TextGray,
            lineHeight = 20.sp
        )
    }
}
