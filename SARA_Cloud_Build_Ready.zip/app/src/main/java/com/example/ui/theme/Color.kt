package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaraDeepObsidian = Color(0xFF05060B)
val SaraSurfaceDark = Color(0xEA0E111B)
val SaraSurfaceElevated = Color(0xE91A1C2C)
val SaraBorderDark = Color(0xFF3B3559)

val SaraCyan = Color(0xFF38BDF8)
val SaraCyanDark = Color(0xFF0284C7)
val SaraTeal = Color(0xFF2DD4BF)

val KuwaitGold = Color(0xFFFBBF24)
val KuwaitGoldMuted = Color(0xFFD97706)
val KuwaitEmerald = Color(0xFF34D399)

val TextWhite = Color(0xFFF8FAFC)
val TextGray = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val UserBubble = Color(0xFF0F4C5C)
val UserBubbleSecondary = Color(0xFF134E4A)
val UserBubbleBorder = Color(0xFF2DD4BF)

val SaraBubble = Color(0xFF162033)
val SaraBubbleSecondary = Color(0xE91A1C2C)
val SaraBubbleBorder = Color(0xFF38BDF8)

val ChipBackground = Color(0xE91A1C2C)
val CardHighlight = Color(0xFF25334A)


// SARA: bright control colors on a semi-transparent black glass UI.
val SaraPink = Color(0xFFFF43BE)
val SaraPurple = Color(0xFFAB69FF)
val SaraOrange = Color(0xFFFF9E42)
val SaraElectricBlue = Color(0xFF39A5FF)
