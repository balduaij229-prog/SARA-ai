package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearnedDocument
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

/**
 * Modal Bottom Sheet allowing users to select an uploaded Firestore document
 * as the active context reference for AI answers, or trigger a new PDF/Text upload.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentReferenceSheet(
    documents: List<LearnedDocument>,
    currentReference: LearnedDocument?,
    onSelectDocument: (LearnedDocument?) -> Unit,
    onUploadNewClick: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SaraSurfaceDark,
        modifier = modifier.testTag("document_reference_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp)
                .padding(bottom = 30.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(KuwaitGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = KuwaitGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "المستندات المرجعية للإجابة",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Text(
                            text = "حدد مستنداً من الجهاز لتجيب سارة بناءً عليه بدقة",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextGray
                        )
                    }
                }

                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action: Upload new PDF/Text to Firestore button
            Button(
                onClick = {
                    onDismiss()
                    onUploadNewClick()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("upload_new_doc_sheet_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KuwaitEmerald,
                    contentColor = SaraDeepObsidian
                )
            ) {
                Icon(imageVector = Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("رفع مستند جديد (PDF أو نص) إلى السحابة", fontWeight = FontWeight.Bold)
            }

            // Clear current reference button if one is active
            if (currentReference != null) {
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        onSelectDocument(null)
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("clear_active_reference_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFF43F5E))
                ) {
                    Text("إلغاء المرجع المحدد (العودة للدردشة العامة)")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = SaraBorderDark)
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "المستندات المحفوظة في قاعدة بياناتك (${documents.size}):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (documents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "لا توجد مستندات بعد. اضغط الزر أعلاه لرفع ملف PDF أو نص.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 340.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(documents, key = { it.id }) { doc ->
                        val isSelected = currentReference?.id == doc.id
                        ReferenceDocItem(
                            doc = doc,
                            isSelected = isSelected,
                            onSelect = {
                                onSelectDocument(doc)
                                onDismiss()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ReferenceDocItem(
    doc: LearnedDocument,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val isPdf = doc.fileType == "pdf"

    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) SaraSurfaceElevated else SaraSurfaceElevated.copy(alpha = 0.5f),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isSelected) KuwaitGold else SaraBorderDark
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("ref_doc_item_${doc.id}")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isPdf) Color(0xFFE11D48).copy(alpha = 0.2f) else SaraCyan.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Description,
                        contentDescription = null,
                        tint = if (isPdf) Color(0xFFF43F5E) else SaraCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = doc.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) KuwaitGold else TextWhite,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isPdf) Color(0xFFE11D48).copy(alpha = 0.2f) else SaraCyan.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (isPdf) "PDF" else "TXT",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isPdf) Color(0xFFF43F5E) else SaraCyan,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = doc.summary.take(70),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextGray,
                        maxLines = 1
                    )
                }
            }

            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(KuwaitGold),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "محدد",
                        tint = SaraDeepObsidian,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

/**
 * Dialog to inspect full extracted text and knowledge from an uploaded Firestore document
 */
@Composable
fun DocumentContentDialog(
    doc: LearnedDocument?,
    onDismiss: () -> Unit,
    onAskAboutDoc: (LearnedDocument) -> Unit
) {
    if (doc == null) return

    val isPdf = doc.fileType == "pdf"

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SaraSurfaceDark,
        shape = RoundedCornerShape(20.dp),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Description,
                    contentDescription = null,
                    tint = if (isPdf) Color(0xFFF43F5E) else KuwaitEmerald,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = doc.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite,
                        maxLines = 1
                    )
                    Text(
                        text = if (isPdf) "مستند PDF مخزن على الجهاز" else "مستند نصي مخزن على الجهاز",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isPdf) Color(0xFFF43F5E) else KuwaitEmerald
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "خلاصة سارة للذكاء الاصطناعي:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = KuwaitGold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SaraSurfaceElevated)
                        .padding(10.dp)
                ) {
                    Text(
                        text = doc.summary,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextWhite,
                        lineHeight = 20.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "المحتوى والنقاط المستخرجة:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = SaraCyan
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(SaraSurfaceElevated)
                        .padding(10.dp)
                ) {
                    Text(
                        text = doc.extractedContent.ifBlank { "تمت معالجة المستند واستخراج ملخصه الرئيسي أعلاه." },
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGray,
                        lineHeight = 18.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onDismiss()
                    onAskAboutDoc(doc)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = SaraCyan,
                    contentColor = SaraDeepObsidian
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("اسأل سارة عن هذا المستند 💬", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إغلاق", color = TextGray)
            }
        }
    )
}

/**
 * Banner displayed above the chat input to indicate that SARA is grounding her responses
 * in a specific uploaded PDF/text document from Firestore.
 */
@Composable
fun ActiveReferenceDocumentBanner(
    document: LearnedDocument,
    onOpenSheet: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isPdf = document.fileType == "pdf"

    Surface(
        color = SaraSurfaceElevated,
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, KuwaitGold.copy(alpha = 0.6f)),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp)
            .testTag("active_reference_doc_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(if (isPdf) Color(0xFFE11D48).copy(alpha = 0.2f) else SaraCyan.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isPdf) Icons.Default.PictureAsPdf else Icons.Default.Description,
                    contentDescription = null,
                    tint = if (isPdf) Color(0xFFF43F5E) else SaraCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "مرجع الإجابة:",
                        style = MaterialTheme.typography.labelSmall,
                        color = KuwaitGold,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = document.title,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite,
                        maxLines = 1
                    )
                }
                Text(
                    text = if (isPdf && document.pageCount > 0)
                        "${document.pageCount} صفحة • سارة تركز إجاباتها على هذا الملف"
                    else
                        "سارة تستند إلى محتوى هذا الملف للإجابة",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextGray
                )
            }

            // Change document button
            TextButton(
                onClick = onOpenSheet,
                modifier = Modifier.testTag("change_reference_doc_button")
            ) {
                Text(
                    text = "تغيير",
                    style = MaterialTheme.typography.labelSmall,
                    color = SaraCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            // Dismiss reference button
            IconButton(
                onClick = onClear,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("dismiss_reference_doc_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إلغاء المرجع",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

