package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import kotlinx.coroutines.delay

/**
 * In-app SARA is intentionally distinct from the BLACK CAT launcher icon.
 * Original SARA artwork: idle, talking and blinking frames supplied by owner.
 * This is a simple illustrated animation, NOT lip synchronization or live video.
 */
@Composable
fun SaraAvatarStage(isSpeaking: Boolean, modifier: Modifier = Modifier) {
    var minimized by remember { mutableStateOf(false) }
    var blinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3600)
            blinking = true
            delay(165)
            blinking = false
        }
    }
    val breathing = rememberInfiniteTransition(label = "sara_breath")
    val breath by breathing.animateFloat(
        initialValue = 1f,
        targetValue = 1.012f,
        animationSpec = infiniteRepeatable(tween(2100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "sara_scale"
    )
    val activeFrame = when {
        blinking -> R.drawable.sara_avatar_blink
        isSpeaking -> R.drawable.sara_avatar_talking
        else -> R.drawable.sara_avatar_idle
    }

    Column(modifier = modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 5.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (minimized) "إظهار سارة ↓" else "تصغير سارة ↑",
                color = SaraPurple,
                fontSize = 12.sp,
                modifier = Modifier.clickable { minimized = !minimized }.padding(4.dp)
            )
        }
        AnimatedVisibility(visible = !minimized) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(235.dp)
                    .clip(RoundedCornerShape(23.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xCC070813), Color(0xCC171025), Color(0xCC070813))
                        )
                    )
                    .border(1.dp, SaraPurple.copy(alpha = 0.52f), RoundedCornerShape(23.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Image preserves owner's hair colors, face and upper-body proportions.
                Image(
                    painter = painterResource(activeFrame),
                    contentDescription = "سارة من الخصر وفوق",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxHeight().scale(breath)
                )
                Text(
                    text = if (isSpeaking) "● سارة تتكلم" else "● سارة معاك",
                    color = if (isSpeaking) SaraPink else SaraCyan,
                    fontSize = 12.sp,
                    modifier = Modifier.align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .background(Color(0xDD080B14), RoundedCornerShape(12.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}
