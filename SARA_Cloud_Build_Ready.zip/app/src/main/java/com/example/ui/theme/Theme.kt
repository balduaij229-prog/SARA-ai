package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = SaraCyan,
    onPrimary = SaraDeepObsidian,
    primaryContainer = SaraCyanDark,
    onPrimaryContainer = TextWhite,
    secondary = SaraTeal,
    onSecondary = SaraDeepObsidian,
    tertiary = KuwaitGold,
    onTertiary = SaraDeepObsidian,
    background = SaraDeepObsidian,
    onBackground = TextWhite,
    surface = SaraSurfaceDark,
    onSurface = TextWhite,
    surfaceVariant = SaraSurfaceElevated,
    onSurfaceVariant = TextGray,
    outline = SaraBorderDark
)

@Composable
fun SaraAiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
