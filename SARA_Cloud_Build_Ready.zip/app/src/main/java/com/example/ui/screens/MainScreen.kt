package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraPink
import com.example.ui.theme.SaraOrange
import com.example.ui.theme.SaraPurple
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.SaraViewModel

enum class NavTab(val title: String, val icon: ImageVector) {
    CHAT("المحادثة", Icons.Default.Forum),
    MEMORY("الذاكرة", Icons.Default.Psychology),
    KNOWLEDGE("المستندات", Icons.Default.Description),
    PROFILE("الإعدادات", Icons.Default.Settings)
}

@Composable
fun MainScreen(
    viewModel: SaraViewModel
) {
    var selectedTab by remember { mutableStateOf(NavTab.CHAT) }
    val snackbarHostState = remember { SnackbarHostState() }
    val infoMessage by viewModel.infoMessage.collectAsState()

    LaunchedEffect(infoMessage) {
        infoMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearInfoMessage()
        }
    }

    // Back handling: if on sub-tab, pressing back returns to CHAT tab
    BackHandler(enabled = selectedTab != NavTab.CHAT) {
        selectedTab = NavTab.CHAT
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = SaraDeepObsidian,
            contentWindowInsets = androidx.compose.foundation.layout.WindowInsets(0, 0, 0, 0),
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            bottomBar = {
                NavigationBar(
                    containerColor = SaraSurfaceDark,
                    contentColor = TextWhite
                ) {
                    NavTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab
                        val accent = when (tab) {
                            NavTab.CHAT -> SaraCyan
                            NavTab.MEMORY -> SaraPink
                            NavTab.KNOWLEDGE -> SaraOrange
                            NavTab.PROFILE -> SaraPurple
                        }
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title
                                )
                            },
                            label = { Text(text = tab.title) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SaraDeepObsidian,
                                selectedTextColor = accent,
                                indicatorColor = accent,
                                unselectedIconColor = accent.copy(alpha = 0.65f),
                                unselectedTextColor = TextGray
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                when (selectedTab) {
                    NavTab.CHAT -> ChatScreen(viewModel = viewModel)
                    NavTab.MEMORY -> MemoryScreen(viewModel = viewModel)
                    NavTab.KNOWLEDGE -> KnowledgeScreen(
                        viewModel = viewModel,
                        onAskAboutDocument = { doc ->
                            viewModel.selectReferenceDocument(doc)
                            selectedTab = NavTab.CHAT
                        }
                    )
                    NavTab.PROFILE -> ProfileScreen(viewModel = viewModel)
                }
            }
        }
    }
}
