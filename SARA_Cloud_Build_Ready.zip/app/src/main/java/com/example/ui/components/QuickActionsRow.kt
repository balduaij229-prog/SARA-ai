package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FormatListBulleted
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material.icons.filled.Translate
import com.example.data.model.LearnedDocument
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.data.model.Message
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.SaraTeal
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextWhite

/**
 * Enumeration of contextual Quick Actions available on the last conversation message.
 */
enum class QuickActionType(
    val id: String,
    val titleAr: String,
    val descriptionAr: String,
    val icon: ImageVector,
    val accentColor: Color,
    val testTag: String
) {
    SUMMARIZE(
        id = "summarize",
        titleAr = "لخص هذا",
        descriptionAr = "تلخيص المحتوى بنقاط واضحة",
        icon = Icons.Default.Summarize,
        accentColor = KuwaitGold,
        testTag = "quick_action_summarize"
    ),
    TRANSLATE_EN(
        id = "translate_en",
        titleAr = "ترجم للإنجليزي",
        descriptionAr = "ترجمة المحتوى بدقة للإنجليزية",
        icon = Icons.Default.Translate,
        accentColor = SaraCyan,
        testTag = "quick_action_translate"
    ),
    DRAFT_REPLY(
        id = "draft_reply",
        titleAr = "اكتب لي رد",
        descriptionAr = "صياغة رد كويتي مهذب ومناسب",
        icon = Icons.Default.EditNote,
        accentColor = KuwaitEmerald,
        testTag = "quick_action_draft_reply"
    ),
    EXPLAIN_MORE(
        id = "explain_more",
        titleAr = "اشرح أكثر",
        descriptionAr = "توضيح مفصل مع أمثلة عملية",
        icon = Icons.Default.Lightbulb,
        accentColor = SaraTeal,
        testTag = "quick_action_explain"
    )
}

/**
 * Formulates a tailored contextual prompt based on the selected action and target message content.
 */
fun buildQuickActionPrompt(actionType: QuickActionType, targetMessage: Message): String {
    val cleanSnippet = targetMessage.content.trim().let { text ->
        if (text.length > 350) text.take(350) + "..." else text
    }.replace("\n", " ")

    return when (actionType) {
        QuickActionType.SUMMARIZE -> {
            "لخص لي هالكلام بإيجاز وبنقاط واضحة ومباشرة:\n\"$cleanSnippet\""
        }
        QuickActionType.TRANSLATE_EN -> {
            "ترجم لي هذا النص بدقة واحترافية إلى اللغة الإنجليزية:\n\"$cleanSnippet\""
        }
        QuickActionType.DRAFT_REPLY -> {
            "صغ لي واكتب رد مناسب واحترافي بلهجة كويتية مهذبة على هذا الكلام:\n\"$cleanSnippet\""
        }
        QuickActionType.EXPLAIN_MORE -> {
            "ممكن توضحين لي هالنقطة أكثر بالتفصيل مع أمثلة عملية ومبسطة من واقع الكويت؟:\n\"$cleanSnippet\""
        }
    }
}

/**
 * Quick Actions row rendered above the chat input bar.
 * Provides one-tap requests ('Summarize this', 'Translate to English', 'Draft a reply', 'Explain further',
 * or document-specific queries when a reference document is active).
 */
@Composable
fun QuickActionsRow(
    lastMessage: Message?,
    isGenerating: Boolean,
    referenceDocument: LearnedDocument? = null,
    onActionSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val isVisible = !isGenerating && (
        (lastMessage != null && lastMessage.content.isNotBlank()) || referenceDocument != null
    )

    AnimatedVisibility(
        visible = isVisible,
        enter = fadeIn() + slideInVertically(initialOffsetY = { it / 2 }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { it / 2 }),
        modifier = modifier
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SaraSurfaceDark.copy(alpha = 0.95f))
                    .padding(vertical = 4.dp)
                    .testTag("quick_actions_row")
            ) {
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Small header badge indicating smart contextual actions
                    item(key = "header_indicator") {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(SaraSurfaceElevated.copy(alpha = 0.6f))
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (referenceDocument != null) Icons.Default.Description else Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (referenceDocument != null) SaraCyan else KuwaitGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (referenceDocument != null) "أسئلة المستند" else "إجراءات سريعة",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextGray,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // If a reference document is active, offer document-specific quick actions first
                    if (referenceDocument != null) {
                        item(key = "doc_summarize") {
                            DocQuickActionChip(
                                title = "لخص المستند 📄",
                                icon = Icons.Default.Summarize,
                                accentColor = KuwaitGold,
                                testTag = "quick_action_doc_summarize",
                                onClick = {
                                    onActionSelected("لخصي لي محتوى مستند \"${referenceDocument.title}\" بأهم النقاط والاستنتاجات الأساسية يا سارة.")
                                }
                            )
                        }
                        item(key = "doc_keypoints") {
                            DocQuickActionChip(
                                title = "أهم النقاط 📌",
                                icon = Icons.Default.FormatListBulleted,
                                accentColor = SaraCyan,
                                testTag = "quick_action_doc_keypoints",
                                onClick = {
                                    onActionSelected("استخرجي لي النقاط والبنود الرئيسية من ملف \"${referenceDocument.title}\".")
                                }
                            )
                        }
                        item(key = "doc_analyze") {
                            DocQuickActionChip(
                                title = "رأيك وتحليلك 💡",
                                icon = Icons.Default.Lightbulb,
                                accentColor = KuwaitEmerald,
                                testTag = "quick_action_doc_analyze",
                                onClick = {
                                    onActionSelected("بناءً على ملف \"${referenceDocument.title}\"، شنو تقييمج وتوصياتج حول محتواه؟")
                                }
                            )
                        }
                    }

                    // Conversation message action chips
                    if (lastMessage != null && lastMessage.content.isNotBlank()) {
                        items(
                            items = QuickActionType.values(),
                            key = { it.id }
                        ) { action ->
                            QuickActionChip(
                                action = action,
                                onClick = {
                                    val prompt = buildQuickActionPrompt(action, lastMessage)
                                    onActionSelected(prompt)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DocQuickActionChip(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = SaraSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = accentColor.copy(alpha = 0.55f)
        ),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = accentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextWhite
            )
        }
    }
}

@Composable
private fun QuickActionChip(
    action: QuickActionType,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = SaraSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = action.accentColor.copy(alpha = 0.45f)
        ),
        modifier = modifier
            .minimumInteractiveComponentSize()
            .testTag(action.testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = action.icon,
                contentDescription = action.descriptionAr,
                tint = action.accentColor,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = action.titleAr,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold,
                color = TextWhite
            )
        }
    }
}
