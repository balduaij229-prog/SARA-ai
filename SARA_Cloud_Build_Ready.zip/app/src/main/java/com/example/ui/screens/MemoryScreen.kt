package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Memory
import com.example.ui.theme.KuwaitEmerald
import com.example.ui.theme.KuwaitGold
import com.example.ui.theme.SaraBorderDark
import com.example.ui.theme.SaraCyan
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.theme.SaraSurfaceDark
import com.example.ui.theme.SaraSurfaceElevated
import com.example.ui.theme.TextGray
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.viewmodel.SaraViewModel

@Composable
fun MemoryScreen(
    viewModel: SaraViewModel
) {
    val memories by viewModel.memories.collectAsState()
    var selectedCategory by remember { mutableStateOf("الكل") }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var memoryToEdit by remember { mutableStateOf<Memory?>(null) }

    val categories = listOf("الكل", "تفضيلات", "العمل", "شخصية", "عامة")

    val filteredMemories = remember(memories, selectedCategory, searchQuery) {
        memories.filter { mem ->
            val matchesCategory = when (selectedCategory) {
                "تفضيلات" -> mem.category == "preference"
                "العمل" -> mem.category == "work"
                "شخصية" -> mem.category == "personal"
                "عامة" -> mem.category == "general"
                else -> true
            }
            val matchesSearch = if (searchQuery.isBlank()) {
                true
            } else {
                mem.title.contains(searchQuery, ignoreCase = true) ||
                        mem.content.contains(searchQuery, ignoreCase = true)
            }
            matchesCategory && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SaraDeepObsidian)
    ) {
        // Top Header
        Surface(
            color = SaraSurfaceDark,
            modifier = Modifier.fillMaxWidth(),
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = KuwaitGold,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ذاكرة سارة الدائمة",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextWhite
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(KuwaitGold.copy(alpha = 0.15f))
                                .padding(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "${memories.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KuwaitGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Text(
                        text = "ما تعلمته سارة عنك وتستخدمه في توجيه ردودها",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextGray
                    )
                }

                Button(
                    onClick = { showAddDialog = true },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = KuwaitGold,
                        contentColor = SaraDeepObsidian
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("add_memory_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "إضافة", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .testTag("memory_search_input"),
            placeholder = { Text("ابحث في الذاكرة (مثال: قهوة، وظيفة، اسم...)", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = KuwaitGold,
                    modifier = Modifier.size(18.dp)
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(
                            imageVector = Icons.Default.Clear,
                            contentDescription = "مسح البحث",
                            tint = TextGray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = KuwaitGold,
                unfocusedBorderColor = SaraBorderDark,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedContainerColor = SaraSurfaceElevated,
                unfocusedContainerColor = SaraSurfaceElevated
            )
        )

        // Category Filter Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val isSelected = cat == selectedCategory
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isSelected) SaraCyan else SaraSurfaceElevated)
                        .border(1.dp, if (isSelected) SaraCyan else SaraBorderDark, RoundedCornerShape(20.dp))
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = cat,
                        color = if (isSelected) SaraDeepObsidian else TextWhite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // Memories List or Empty State
        if (filteredMemories.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = null,
                        tint = KuwaitGold.copy(alpha = 0.5f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "لا توجد نتائج تطابق بحثك" else "لا توجد ذكريات في هذا القسم بعد",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (searchQuery.isNotBlank()) "جرب البحث بكلمة أخرى" else "سارة تتعلم تلقائياً من محادثاتك، أو يمكنك إضافة تفضيلاتك وتعديلها يدوياً هنا!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextGray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredMemories, key = { it.id }) { memory ->
                    MemoryCard(
                        memory = memory,
                        onEdit = { memoryToEdit = memory },
                        onDelete = { viewModel.deleteMemory(memory.id) }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        MemoryEditorDialog(
            dialogTitle = "علّم سارة معلومة جديدة",
            initialTitle = "",
            initialContent = "",
            initialCategory = "preference",
            initialImportance = 4,
            confirmButtonLabel = "حفظ في الذاكرة",
            onDismiss = { showAddDialog = false },
            onSave = { title, content, cat, importance ->
                viewModel.addManualMemory(title, content, cat, importance)
                showAddDialog = false
            }
        )
    }

    memoryToEdit?.let { memory ->
        MemoryEditorDialog(
            dialogTitle = "تعديل معلومة في الذاكرة",
            initialTitle = memory.title,
            initialContent = memory.content,
            initialCategory = memory.category,
            initialImportance = memory.importance,
            confirmButtonLabel = "تحديث المعلومة",
            onDismiss = { memoryToEdit = null },
            onSave = { title, content, cat, importance ->
                viewModel.updateMemory(memory.id, title, content, cat, importance)
                memoryToEdit = null
            }
        )
    }
}

@Composable
private fun MemoryCard(
    memory: Memory,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    val (categoryLabel, categoryColor) = when (memory.category) {
        "preference" -> "تفضيل شخصي" to KuwaitGold
        "work" -> "العمل والروتين" to SaraCyan
        "personal" -> "شخصي" to KuwaitEmerald
        else -> "عام" to TextGray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(SaraSurfaceDark)
            .border(1.dp, SaraBorderDark, RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("memory_card_${memory.id}"),
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(categoryColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = categoryLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = categoryColor,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Importance stars
                Row {
                    repeat(memory.importance.coerceIn(1, 5)) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = KuwaitGold,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = memory.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = memory.content,
                style = MaterialTheme.typography.bodyMedium,
                color = TextGray,
                lineHeight = 22.sp
            )
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onEdit,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("edit_memory_button_${memory.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "تعديل الذكرى",
                    tint = KuwaitGold,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier
                    .size(36.dp)
                    .testTag("delete_memory_button_${memory.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "حذف الذكرى",
                    tint = TextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun MemoryEditorDialog(
    dialogTitle: String,
    initialTitle: String,
    initialContent: String,
    initialCategory: String,
    initialImportance: Int,
    confirmButtonLabel: String,
    onDismiss: () -> Unit,
    onSave: (String, String, String, Int) -> Unit
) {
    var title by remember { mutableStateOf(initialTitle) }
    var content by remember { mutableStateOf(initialContent) }
    var selectedCategoryKey by remember { mutableStateOf(initialCategory) }
    var importance by remember { mutableIntStateOf(initialImportance) }

    val catOptions = listOf(
        "preference" to "تفضيل",
        "work" to "عمل",
        "personal" to "شخصي",
        "general" to "عام"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SaraSurfaceElevated,
        title = {
            Text(
                text = dialogTitle,
                color = TextWhite,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("عنوان المعلومة (مثال: المطعم المفضل)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("memory_dialog_title_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = KuwaitGold,
                        unfocusedBorderColor = SaraBorderDark,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedLabelColor = KuwaitGold,
                        unfocusedLabelColor = TextGray
                    )
                )

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("التفاصيل (مثال: أحب أطلب من مطعم ميس الغانم)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("memory_dialog_content_input"),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = KuwaitGold,
                        unfocusedBorderColor = SaraBorderDark,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedLabelColor = KuwaitGold,
                        unfocusedLabelColor = TextGray
                    ),
                    maxLines = 4
                )

                Text(
                    text = "التصنيف:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    catOptions.forEach { (key, label) ->
                        val isSel = selectedCategoryKey == key
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) KuwaitGold else SaraSurfaceDark)
                                .clickable { selectedCategoryKey = key }
                                .padding(vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSel) SaraDeepObsidian else TextWhite,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Text(
                    text = "درجة الأهمية في توجيه الردود:",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextGray
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    (1..5).forEach { star ->
                        IconButton(
                            onClick = { importance = star },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = "$star نجوم",
                                tint = if (star <= importance) KuwaitGold else TextMuted,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onSave(title, content, selectedCategoryKey, importance)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = KuwaitGold,
                    contentColor = SaraDeepObsidian
                ),
                enabled = title.isNotBlank() && content.isNotBlank(),
                modifier = Modifier.testTag("memory_dialog_save_button")
            ) {
                Text(confirmButtonLabel, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = TextGray)
            }
        }
    )
}
