package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.ai.SaraAiService
import com.example.data.repository.SaraRepository
import com.example.ui.screens.MainScreen
import com.example.ui.theme.SaraAiTheme
import com.example.ui.theme.SaraDeepObsidian
import com.example.ui.viewmodel.SaraViewModel
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Step 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            SaraAiTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = SaraDeepObsidian,
                    contentWindowInsets = WindowInsets.safeDrawing
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        SaraApp()
                    }
                }
            }
        }
    }
}

@Composable
fun SaraApp() {
    // One device owner; no Google login, no Firebase Authentication gate.
    val context = LocalContext.current
    val repository = remember { SaraRepository(context.applicationContext) }
    val aiService = remember { SaraAiService() }
    val viewModel: SaraViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                SaraViewModel(
                    repository = repository,
                    aiService = aiService,
                    currentUserId = "local-owner",
                    userDisplayName = "صديق سارة",
                    userEmail = null
                )
            }
        }
    )
    MainScreen(viewModel = viewModel)
}
