package com.example.data.model

/**
 * Represents the customizable voice and persona modes for SARA AI.
 * Each mode defines specific pitch, speech rate, and persona prompt adjustments.
 */
enum class SaraVoiceMode(
    val id: String,
    val title: String,
    val subtitle: String,
    val description: String,
    val pitch: Float,
    val speed: Float,
    val sampleText: String,
    val promptInstruction: String
) {
    FRIENDLY_KUWAITI(
        id = "friendly_kuwaiti",
        title = "ودودة وعفوية 🇰🇼",
        subtitle = "يا هلا وغلا وعيوني لك",
        description = "نبرة دافئة مرحبة مفعمة بالحفاوة الكويتية والكلمات الدارجة المحبوبة",
        pitch = 1.08f,
        speed = 0.94f,
        sampleText = "يا هلا ومسهلا فيك! آمرني وتدلل، عيوني لك وما طلبت شي يا الغالي.",
        promptInstruction = "نبرة الصوت والأسلوب: ودودة وعفوية ومرحبة جداً بأصالة كويتية (يا هلا وغلا، عيوني لك، تامر أمر، خوش فكرة، يبيله، فالك طيب)."
    ),
    PROFESSIONAL_OFFICIAL(
        id = "professional",
        title = "رسمية واحترافية 💼",
        subtitle = "أهلاً بك، تفضل بالاطلاع",
        description = "نبرة متزنة وأنيقة تناسب بيئة الأعمال والتقارير والمعاملات والمراسلات",
        pitch = 1.00f,
        speed = 1.00f,
        sampleText = "أهلاً ومرحباً بك. يسعدني تقديم المساعدة المهنية والحلول الدقيقة لكافة مهامك.",
        promptInstruction = "نبرة الصوت والأسلوب: مهنية ورسمية، واضحة ومباشرة وراقية، موجهة لإنجاز الأعمال والمهام بأعلى درجات الدقة والترتيب."
    ),
    CALM_CONCISE(
        id = "calm_concise",
        title = "هادئة وموجزة 🕊️",
        subtitle = "إجابات مباشرة ومختصرة",
        description = "نبرة هادئة ومريحة، إجابات ملخصة وموجزة تركز على النقطة الأساسية دون إطالة",
        pitch = 0.94f,
        speed = 0.90f,
        sampleText = "مرحباً بك.. الجواب باختصار هو المطلوب تماماً وبكل بساطة وهدوء.",
        promptInstruction = "نبرة الصوت والأسلوب: هادئة ولطيفة وموجزة للغاية، تكتفي بالجواب الشافي والمباشر دون إسهاب أو مقدمات طويلة."
    ),
    STORYTELLER(
        id = "storyteller",
        title = "راوية ودافئة 📖",
        subtitle = "أسلوب قصصي وتعبيري عميق",
        description = "إلقاء تعبيري شجي يستحضر تراث الكويت وسوالف الديرة بأجواء دافئة",
        pitch = 1.04f,
        speed = 0.86f,
        sampleText = "يا حيا الله السوالف الطيبة وريحة الماضي.. تعال نسولف عن الديرة وأهلها الطيبين.",
        promptInstruction = "نبرة الصوت والأسلوب: أسلوب قصصي دافئ وشائق وتعبيري، يستحضر جمال المعاني والقصص وتراث الديرة وسوالفها العريقة."
    );

    companion object {
        fun fromId(id: String?): SaraVoiceMode {
            return values().find { it.id.equals(id, ignoreCase = true) } ?: FRIENDLY_KUWAITI
        }
    }
}
