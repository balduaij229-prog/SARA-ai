package com.example.data.repository

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.data.model.Conversation
import com.example.data.model.LearnedDocument
import com.example.data.model.Memory
import com.example.data.model.Message
import com.example.data.model.UserProfile
import com.google.firebase.Timestamp
import java.util.Date
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext

/**
 * Local-only, single-user SARA repository. No Firebase Authentication / Firestore calls.
 * SQLite is private app storage. No network requests or account required for persistence.
 * Existing Firestore history is NOT silently imported or deleted.
 */
class SaraRepository(context: Context) {
    private val helper = LocalSaraDb(context.applicationContext)
    private val prefs = context.applicationContext.getSharedPreferences("sara_profile", Context.MODE_PRIVATE)
    private val changes = MutableStateFlow(0L)
    private val ownerId = "local-owner"

    private fun notifyChanged() { changes.value = changes.value + 1L }
    private fun now(): Long = System.currentTimeMillis()
    private fun stamp(epoch: Long): Timestamp = Timestamp(Date(epoch))
    private fun Cursor.s(key: String): String = getString(getColumnIndexOrThrow(key)) ?: ""
    private fun Cursor.opt(key: String): String? = getString(getColumnIndexOrThrow(key))
    private fun Cursor.n(key: String): Int = getInt(getColumnIndexOrThrow(key))
    private fun Cursor.l(key: String): Long = getLong(getColumnIndexOrThrow(key))

    private inline fun <T> safeWrite(block: () -> T): Result<T> = try {
        val answer = block()
        notifyChanged()
        Result.success(answer)
    } catch (e: Exception) { Result.failure(e) }

    suspend fun getOrCreateProfile(displayName: String, email: String?): Result<UserProfile> =
        withContext(Dispatchers.IO) {
            Result.success(UserProfile(
                id = ownerId, userId = ownerId,
                displayName = prefs.getString("name", displayName) ?: displayName,
                email = null, preferredDialect = prefs.getString("dialect", "kuwaiti") ?: "kuwaiti",
                voiceMode = prefs.getString("voice", "friendly_kuwaiti") ?: "friendly_kuwaiti",
                memoryPrivacyEnabled = prefs.getBoolean("privacy", true)
            ))
        }

    suspend fun updateDialect(preferredDialect: String): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { check(prefs.edit().putString("dialect", preferredDialect).commit()) }
    }
    suspend fun updateVoiceMode(voiceMode: String): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { check(prefs.edit().putString("voice", voiceMode).commit()) }
    }
    suspend fun updateMemoryPrivacy(enabled: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { check(prefs.edit().putBoolean("privacy", enabled).commit()) }
    }

    fun observeConversations(): Flow<List<Conversation>> = changes.map {
        val list = mutableListOf<Conversation>()
        helper.readableDatabase.rawQuery("SELECT * FROM conversations ORDER BY updated_at DESC", null).use { c ->
            while (c.moveToNext()) list.add(Conversation(
                id = c.s("id"), userId = ownerId, title = c.s("title"),
                lastMessage = c.s("last_message"), messageCount = c.n("message_count"),
                createdAt = stamp(c.l("created_at")), updatedAt = stamp(c.l("updated_at"))
            ))
        }
        list
    }.flowOn(Dispatchers.IO)

    suspend fun createConversation(title: String): Result<String> = withContext(Dispatchers.IO) {
        safeWrite {
            val id = UUID.randomUUID().toString()
            val t = now()
            val values = ContentValues().apply {
                put("id", id); put("title", title.ifBlank { "محادثة جديدة" }); put("last_message", "")
                put("message_count", 0); put("created_at", t); put("updated_at", t)
            }
            check(helper.writableDatabase.insertOrThrow("conversations", null, values) != -1L)
            id
        }
    }

    suspend fun deleteConversation(conversationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite {
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                db.delete("messages", "conversation_id=?", arrayOf(conversationId))
                db.delete("conversations", "id=?", arrayOf(conversationId))
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
        }
    }

    fun observeMessages(conversationId: String): Flow<List<Message>> = changes.map {
        val list = mutableListOf<Message>()
        helper.readableDatabase.rawQuery(
            "SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at ASC, rowid ASC",
            arrayOf(conversationId)
        ).use { c ->
            while (c.moveToNext()) list.add(Message(
                id = c.s("id"), userId = ownerId, role = c.s("role"),
                content = c.s("content"), attachmentType = c.s("attachment_type"),
                attachmentName = c.opt("attachment_name"), createdAt = stamp(c.l("created_at"))
            ))
        }
        list
    }.flowOn(Dispatchers.IO)

    suspend fun addMessage(
        conversationId: String, role: String, content: String,
        attachmentType: String = "none", attachmentName: String? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        safeWrite {
            val id = UUID.randomUUID().toString()
            val t = now()
            val db = helper.writableDatabase
            db.beginTransaction()
            try {
                val values = ContentValues().apply {
                    put("id", id); put("conversation_id", conversationId); put("role", role)
                    put("content", content); put("attachment_type", attachmentType)
                    put("attachment_name", attachmentName); put("created_at", t)
                }
                db.insertOrThrow("messages", null, values)
                val conversation = ContentValues().apply {
                    put("last_message", content.take(100)); put("updated_at", t)
                }
                check(db.update("conversations", conversation, "id=?", arrayOf(conversationId)) > 0)
                db.execSQL("UPDATE conversations SET message_count=message_count+1 WHERE id=?", arrayOf(conversationId))
                db.setTransactionSuccessful()
            } finally { db.endTransaction() }
            id
        }
    }

    fun observeMemories(): Flow<List<Memory>> = changes.map {
        val list = mutableListOf<Memory>()
        helper.readableDatabase.rawQuery("SELECT * FROM memories ORDER BY created_at DESC", null).use { c ->
            while (c.moveToNext()) list.add(Memory(
                id = c.s("id"), userId = ownerId, title = c.s("title"),
                content = c.s("content"), category = c.s("category"), importance = c.n("importance"),
                createdAt = stamp(c.l("created_at")), updatedAt = stamp(c.l("updated_at"))
            ))
        }
        list
    }.flowOn(Dispatchers.IO)

    suspend fun addMemory(
        title: String, content: String, category: String = "general", importance: Int = 3
    ): Result<String> = withContext(Dispatchers.IO) {
        safeWrite {
            val id = UUID.randomUUID().toString(); val t = now()
            val values = ContentValues().apply {
                put("id", id); put("title", title.take(200)); put("content", content.take(5000))
                put("category", category.category()); put("importance", importance.coerceIn(1, 5))
                put("created_at", t); put("updated_at", t)
            }
            helper.writableDatabase.insertOrThrow("memories", null, values)
            id
        }
    }

    suspend fun updateMemory(
        memoryId: String, title: String, content: String, category: String = "general", importance: Int = 3
    ): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite {
            val values = ContentValues().apply {
                put("title", title.take(200)); put("content", content.take(5000))
                put("category", category.category()); put("importance", importance.coerceIn(1, 5)); put("updated_at", now())
            }
            check(helper.writableDatabase.update("memories", values, "id=?", arrayOf(memoryId)) > 0)
        }
    }
    private fun String.category(): String = if (this in setOf("personal", "work", "preference", "general")) this else "general"

    suspend fun deleteMemory(memoryId: String): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { helper.writableDatabase.delete("memories", "id=?", arrayOf(memoryId)); Unit }
    }
    suspend fun clearAllMemories(): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { helper.writableDatabase.delete("memories", null, null); Unit }
    }

    fun observeDocuments(): Flow<List<LearnedDocument>> = changes.map {
        val list = mutableListOf<LearnedDocument>()
        helper.readableDatabase.rawQuery("SELECT * FROM documents ORDER BY created_at DESC", null).use { c ->
            while (c.moveToNext()) list.add(LearnedDocument(
                id = c.s("id"), userId = ownerId, title = c.s("title"), summary = c.s("summary"),
                extractedContent = c.s("extracted_content"), fileType = c.s("file_type"),
                fileSizeBytes = c.l("file_size_bytes"), pageCount = c.n("page_count"),
                createdAt = stamp(c.l("created_at")), updatedAt = stamp(c.l("updated_at"))
            ))
        }
        list
    }.flowOn(Dispatchers.IO)

    suspend fun addDocument(
        title: String, summary: String, extractedContent: String,
        fileType: String = "text", fileSizeBytes: Long = 0L, pageCount: Int = 1
    ): Result<String> = withContext(Dispatchers.IO) {
        safeWrite {
            val id = UUID.randomUUID().toString(); val t = now()
            val values = ContentValues().apply {
                put("id", id); put("title", title.take(200)); put("summary", summary.take(5000))
                put("extracted_content", extractedContent.take(50000));
                put("file_type", if (fileType in setOf("pdf", "text", "image", "note")) fileType else "text")
                put("file_size_bytes", fileSizeBytes); put("page_count", pageCount.coerceAtLeast(1))
                put("created_at", t); put("updated_at", t)
            }
            helper.writableDatabase.insertOrThrow("documents", null, values)
            id
        }
    }
    suspend fun deleteDocument(documentId: String): Result<Unit> = withContext(Dispatchers.IO) {
        safeWrite { helper.writableDatabase.delete("documents", "id=?", arrayOf(documentId)); Unit }
    }
}

/** App-private, disk-persisted database; no cloud synchronization. */
private class LocalSaraDb(context: Context) : SQLiteOpenHelper(context, "sara_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE conversations (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, last_message TEXT NOT NULL DEFAULT '',
            message_count INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE messages (
            id TEXT PRIMARY KEY, conversation_id TEXT NOT NULL, role TEXT NOT NULL, content TEXT NOT NULL,
            attachment_type TEXT NOT NULL DEFAULT 'none', attachment_name TEXT,
            created_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at)")
        db.execSQL("""CREATE TABLE memories (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, content TEXT NOT NULL,
            category TEXT NOT NULL, importance INTEGER NOT NULL, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE documents (
            id TEXT PRIMARY KEY, title TEXT NOT NULL, summary TEXT NOT NULL,
            extracted_content TEXT NOT NULL, file_type TEXT NOT NULL,
            file_size_bytes INTEGER NOT NULL, page_count INTEGER NOT NULL,
            created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Future schema versions MUST migrate without dropping the owner's data.
        throw IllegalStateException("Missing migration from $oldVersion to $newVersion")
    }
}
