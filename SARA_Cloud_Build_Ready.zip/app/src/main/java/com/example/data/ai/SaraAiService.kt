package com.example.data.ai

import android.graphics.Bitmap
import android.util.Log
import com.example.data.model.LearnedDocument
import com.example.data.model.Memory
import com.example.data.model.Message
import com.example.data.model.SaraVoiceMode
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.ImagePart
import com.google.firebase.ai.type.Part
import com.google.firebase.ai.type.TextPart
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout

private const val TAG = "SaraAiService"

data class DocumentAnalysisResult(
    val title: String,
    val summary: String,
    val keyPoints: String
)

class SaraAiService {

    private val baseSystemInstruction = """
        أنتِ "سارة" (SARA AI) — المساعدة الذكية الشخصية الكويتية المخلصة والمقربة للمستخدم.

        الهوية والروح العامة:
        - روحك كويتية أصيلة، بشوشة، مرحبة، مفعمة بالنخوة والفزعة والضيافة، ذكية وسريعة البديهة، ولبقة كأنك صديقة مخلصة من "أهل الديرة".
        - تتحدثين بلهجة كويتية حية وأصيلة، عفوية ودافئة دون تصنّع، تجمع بين الأصالة والأسلوب العصري الراقي.

        الترحيب والحفاوة الكويتية الأصيلة (Greetings & Warm Hospitality):
        - بادري بالترحيب الصادق والحار دائماً:
          • التحايا: "يا هلا ومسهلا"، "يا هلا وغلا وتو ما نورت"، "حياك الله والساعة المباركة"، "أرحِب يا الغالي" / "حياج الله يا الغالية"، "صباحك ورد وجوري"، "مساك الله بالخير والكرامة".
          • الاطمئنان والمودة: "شلونك وشخبارك؟ عساك بخير وصحة؟"، "عساك عالقوة ورايتك بيضا".
          • عند الشكر والثناء: "تستاهل الطيب"، "ما سوينا شي يا الغالي"، "ما قصرت وبيض الله وجهك"، "الله يعافيك ويسلمك من كل شر".

        الفزعة والجاهزية للخدمة (Eagerness & Readiness to Help):
        - أظهري الاستعداد التام والاهتمام:
          • "آمرني وتدلل، عيوني لك"
          • "ما طلبت شي، حاضر ومن عيوني الثنتين"
          • "فالك طيب وما يصير خاطرك إلا طيب"
          • "أبشر بسعدك / أبشر بعزك"
          • "تامر أمر وعلى راسي"
          • "ولا يهمك، أضبطك بأحسن ترتيب"
          • "ولا تهون، أنا بالخدمة بأي وقت"

        المفردات والتراكيب الكويتية الدارجة (Local Idioms & Everyday Vocabulary):
        - وظفي العبارات والمصطلحات الكويتية الطبيعية في موضعها المناسب:
          • "خوش": لوصف الأمور الممتازة والخيارات الرائعة (خوش فكرة، خوش مشروع، خوش حل، خوش ترتيب).
          • "وايد": للدلالة على الكثرة والأهمية (وايد زين، وايد ممتاز، وايد مشكور).
          • "يبيله": للاقتراح المحفز والممتع (يبيله قهوة تروق، يبيله قعدة وتخطيط، يبيله نخلص هذا الشغل الحين).
          • "سالفة" / "شالسالفة؟" / "السالفة وما فيها".
          • "صج؟" / "صج والله" عند التفاعل باهتمام.
          • "شرايك؟" / "شنو في بالك؟" / "شنو ودك نسوي اليوم؟".
          • "الحين" (الآن)، "تو الناس" (للبقاء والتريث)، "دربالك" (انتبه)، "على طريف" (جاهز ومترقب).
          • "عسى ما شر؟" عند الاستفسار والمواساة، و"خطاك السو" في مواقف السلامة.

        المعرفة الثقافية ونمط الحياة في الكويت (Cultural Nuances & Local Context):
        - تفهمين تفاصيل الحياة اليومية في الكويت:
          • الأماكن والمشاوير: المباركية وسوقها العريق، الأفنيوز، مروج، شاطئ الشويخ وجسر جابر، كافيهات الشويخ الصناعية، الخيران وشاليهات البحر.
          • الدوامات والشوارع: زحمة الدائري الرابع والخامس والسادس، طريق الغزالي وطريق الملك فهد.
          • المواسم والأجواء: كشتات البر والمخيمات بالشتاء، ليالي رمضان والغبقات والزوّارات والقرقيعان، حر الصيف والرطوبة والحاجة للأماكن الباردة والقهوة المثلجة، وموسم السرايات والغبار.
          • التقاليد والضيافة: زوارة الأهل يوم الجمعة، قعدة الديوانية، الجاي والقهوة العربية المتبهرة بالهيل والزعفران، التمور وحلويات الديرة (محلبة، قرص عقيلي، درابيل، غريبة)، والأكلات الكويتية الشهيرة (مجبوس دياي أو لحم، مطبق زبيدي، برياني، بلاليط).

        الذكاء والاحترافية التقنية والمهنية (Intellectual & Professional Excellence):
        - تتمتعين بذكاء تحليلي فائق وقدرات متقدمة في:
          • كتابة الخطابات والإيميلات والتقارير المهنية وصياغتها بدقة بالغة.
          • البرمجة وحل المشكلات التقنية وتحليل الأكواد وتصحيحها.
          • تلخيص المستندات المعقدة واستخلاص النقاط الجوهرية.
          • التوفيق بين الدفء والروح الكويتية المحبوبة في الحوار، والجدية والدقة المتناهية في صلب المهام والحلول.

        استخدام الذاكرة والمعرفة الشخصية:
        - استعيني بالمعلومات الموجودة في "ذاكرة سارة" والمستندات المعرفية للمستخدم، واستشهدي باهتماماته وتفضيلاته بلبقة وكأنك رفيقته المقربة التي تحفظ تفاصيله وتسهر على راحته.

        ضوابط الأسلوب:
        - كوني مختصرة ومفيدة، وتجنبي الحشو أو الإطالة غير الضرورية إلا إذا طلب منك المستخدم تفاصيل إضافية.
        - اللهجة كويتية نقية وطبيعية وعصرية (ليست خليطاً ولا مصطنعة).
    """.trimIndent()

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    /**
     * Stream response from Gemini 3.8 Flash with full memory, voice mode, and knowledge augmentation
     */
    fun streamResponse(
        userPrompt: String,
        conversationHistory: List<Message>,
        memories: List<Memory>,
        documents: List<LearnedDocument>,
        preferredDialect: String = "kuwaiti",
        voiceMode: SaraVoiceMode = SaraVoiceMode.FRIENDLY_KUWAITI,
        referenceDocument: LearnedDocument? = null,
        imageBitmap: Bitmap? = null
    ): Flow<String> = flow {
        val memoryContext = buildString {
            if (referenceDocument != null) {
                append("--- المستند المرجعي الأساسي المحدد للإجابة من قبل المستخدم ---\n")
                append("اسم المستند: ${referenceDocument.title}\n")
                append("نوع الملف: ${referenceDocument.fileType}\n")
                append("خلاصة المستند:\n${referenceDocument.summary}\n")
                if (referenceDocument.extractedContent.isNotBlank()) {
                    append("المحتوى والتفاصيل المستخرجة من المستند:\n${referenceDocument.extractedContent}\n")
                }
                append("توجيه هام: المستخدم يسأل تحديداً بالاعتماد على هذا المستند. استندي إلى حقائقه وبياناته مباشرة وقدّمي إجابة وافية ودقيقة بلهجتك الكويتية الودودة مع ذكر التفاصيل المستخرجة منه.\n\n")
            }
            if (memories.isNotEmpty()) {
                append("--- ذاكرة سارة طويلة المدى عن المستخدم (حقائق وتفضيلات مؤكدة ومسترجعة من الجهاز) ---\n")
                // Sort by importance descending so high-priority constraints (allergies, identity, work) are first
                memories.sortedByDescending { it.importance }.take(30).forEach { mem ->
                    append("• [${mem.category} - أهمية ${mem.importance}/5] ${mem.title}: ${mem.content}\n")
                }
                append("توجيه إلزامي للذاكرة: هذه المعلومات مؤكدة وحفظتِها سابقاً من المستخدم. استرجعيها واستندي إليها في إجاباتك. إذا سألك المستخدم عما إذا كنتِ تعرفين اسمه، وظيفته، مشروبه، عاداته، أو أي معلومة هنا، أظهري تذكركِ لها بدقة وبلهجتكِ الكويتية الودودة (مثال: \"أكيد أذكر..\" أو \"من عيوني..\") ولا تسأليه مجدداً عن تفاصيل مسجلة هنا.\n\n")
            }
            if (documents.isNotEmpty()) {
                append("--- المستندات والمعارف التي تم تعليمها لسارة ---\n")
                documents.take(5).forEach { doc ->
                    append("• مستند: ${doc.title}\nالملخص: ${doc.summary}\nالنقاط المستخرجة: ${doc.extractedContent.take(500)}\n")
                }
                append("\n")
            }
        }

        val dialectGuidance = if (preferredDialect == "modern_standard") {
            "توجيه اللهجة: تحدثي باللغة العربية الفصحى المبسطة والودودة مع الحفاظ على روح سارة الدافئة والمخلصة."
        } else {
            "توجيه اللهجة: تحدثي بلهجتك الكويتية الأصيلة الدافئة والعفوية، مع توظيف التحايا والعبارات والمفردات الكويتية المحبوبة (يا هلا وغلا، عيوني لك، خوش فكرة، يبيله، فالك طيب)."
        }

        val fullPrompt = buildString {
            append(baseSystemInstruction)
            append("\n\n")
            append(dialectGuidance)
            append("\n\n")
            append("--- توجيه نمط الصوت والشخصية المحددة ---\n")
            append(voiceMode.promptInstruction)
            append("\n\n")
            if (memoryContext.isNotBlank()) {
                append(memoryContext)
                append("\n")
            }
            if (conversationHistory.isNotEmpty()) {
                append("--- سياق المحادثة الأخيرة ---\n")
                conversationHistory.takeLast(6).forEach { msg ->
                    val sender = if (msg.role == "user") "المستخدم" else "سارة"
                    append("$sender: ${msg.content}\n")
                }
                append("\n")
            }
            append("المستخدم يقول: $userPrompt")
        }

        val parts = mutableListOf<Part>(TextPart(fullPrompt))
        if (imageBitmap != null) {
            parts.add(ImagePart(imageBitmap))
        }
        val contentPayload = Content("user", parts)

        try {
            withTimeout(60_000L) {
                model.generateContentStream(contentPayload).collect { response ->
                    val chunkText = response.text.orEmpty()
                    if (chunkText.isNotEmpty()) {
                        emit(chunkText)
                    }
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Error in streamResponse", e)
            throw e
        }
    }

    /**
     * Analyze an uploaded document or photo to teach SARA
     */
    suspend fun analyzeDocument(
        fileName: String,
        textContent: String,
        imageBitmap: Bitmap? = null
    ): DocumentAnalysisResult {
        val prompt = """
            قم بتحليل هذا المستند أو الصورة المقدمة لتعليم المساعد الشخصي الذكي "سارة":
            اسم الملف: $fileName
            
            المطلوب:
            1. لخص المستند في 2-3 أسطر باللغة العربية (ملخص وافي ودقيق).
            2. استخرج أهم 3 إلى 5 نقاط رئيسية أو معلومات هامة يجب أن تتذكرها سارة دائماً عند سؤالها.
            
            اجعل الناتج بهذه الصيغة المحددة تماماً:
            [SUMMARY]
            (ضع الملخص هنا)
            [KEY_POINTS]
            (ضع النقاط الرئيسية هنا، كل نقطة في سطر يبدأ بـ •)
        """.trimIndent()

        val fullText = if (textContent.isNotBlank()) {
            "$prompt\n\nنص المستند:\n${textContent.take(15000)}"
        } else {
            prompt
        }

        val parts = mutableListOf<Part>(TextPart(fullText))
        if (imageBitmap != null) {
            parts.add(ImagePart(imageBitmap))
        }
        val contentPayload = Content("user", parts)

        return try {
            val response = withTimeout(60_000L) {
                model.generateContent(contentPayload)
            }
            val text = response.text.orEmpty()

            val summary = if (text.contains("[SUMMARY]") && text.contains("[KEY_POINTS]")) {
                text.substringAfter("[SUMMARY]").substringBefore("[KEY_POINTS]").trim()
            } else {
                text.take(300).trim()
            }

            val keyPoints = if (text.contains("[KEY_POINTS]")) {
                text.substringAfter("[KEY_POINTS]").trim()
            } else {
                text.drop(300).trim().ifBlank { "تمت المعالجة وحفظ المحتوى بنجاح." }
            }

            DocumentAnalysisResult(
                title = fileName,
                summary = summary.ifBlank { "مستند تم استيعابه وحفظه في ذاكرة سارة." },
                keyPoints = keyPoints.ifBlank { "تم استخراج المعرفة وحفظها بنجاح." }
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Document analysis failed", e)
            DocumentAnalysisResult(
                title = fileName,
                summary = "مستند: $fileName",
                keyPoints = textContent.take(500).ifBlank { "تم رفع الملف واستيعابه." }
            )
        }
    }
}
