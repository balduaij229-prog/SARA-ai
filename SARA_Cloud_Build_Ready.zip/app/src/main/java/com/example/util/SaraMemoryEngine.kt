package com.example.util

import com.example.data.model.Memory

sealed class MemoryDecision {
    object NoChange : MemoryDecision()

    data class Create(
        val title: String,
        val content: String,
        val category: String,
        val importance: Int
    ) : MemoryDecision()

    data class Update(
        val existingMemoryId: String,
        val title: String,
        val content: String,
        val category: String,
        val importance: Int
    ) : MemoryDecision()
}

/**
 * Intelligent Memory Engine for SARA AI:
 * - Detects facts, preferences, routines, and identity in natural Arabic/Kuwaiti speech.
 * - Prevents duplicate memories from cluttering Firestore.
 * - Detects corrections and updates existing memories rather than adding conflicting duplicates.
 */
object SaraMemoryEngine {

    /**
     * Analyzes user prompt against existing memories in Firestore,
     * returning a [MemoryDecision] (Create, Update, or NoChange).
     */
    fun analyzeAndDecide(
        userPrompt: String,
        existingMemories: List<Memory>
    ): MemoryDecision {
        val trimmed = userPrompt.trim()
        if (trimmed.length < 4) return MemoryDecision.NoChange

        val candidate = extractMemoryCandidate(trimmed) ?: return MemoryDecision.NoChange

        // Search for existing memory on the same topic to update or deduplicate
        val matchingExisting = findMatchingMemory(candidate, existingMemories)

        if (matchingExisting != null) {
            val lower = trimmed.lowercase()
            val cleanExisting = normalizeForComparison(matchingExisting.content)
            val cleanNew = normalizeForComparison(candidate.content)

            // Extract core words for semantic overlap check
            val existingKws = extractKeywords(matchingExisting.content).toSet()
            val candidateKws = extractKeywords(candidate.content).toSet()

            val overlapCount = candidateKws.count { it in existingKws }
            val isDuplicate = (candidateKws.isNotEmpty() && overlapCount >= (candidateKws.size * 0.6).toInt()) ||
                    cleanExisting == cleanNew || cleanExisting.contains(cleanNew) || cleanNew.contains(cleanExisting)

            val isExplicitCorrection = lower.contains("غيرت") || lower.contains("بدلت") || lower.contains("صرت") ||
                    lower.contains("تعديل") || lower.contains("الجديد") || lower.contains("بدل")

            // If it's a known fact without correction, avoid saving duplicate
            if (isDuplicate && !isExplicitCorrection) {
                return MemoryDecision.NoChange
            }

            // User corrected or updated the information: update the existing Firestore doc
            val updatedTitle = if (candidate.title.length > matchingExisting.title.length) candidate.title else matchingExisting.title
            val updatedCategory = if (candidate.category != "general") candidate.category else matchingExisting.category
            val updatedImportance = maxOf(candidate.importance, matchingExisting.importance)

            return MemoryDecision.Update(
                existingMemoryId = matchingExisting.id,
                title = updatedTitle,
                content = candidate.content,
                category = updatedCategory,
                importance = updatedImportance
            )
        }

        // No prior memory on this topic: create new memory document
        return MemoryDecision.Create(
            title = candidate.title,
            content = candidate.content,
            category = candidate.category,
            importance = candidate.importance
        )
    }

    private data class MemoryCandidate(
        val title: String,
        val content: String,
        val category: String,
        val importance: Int,
        val topicKeywords: List<String>
    )

    private fun extractMemoryCandidate(text: String): MemoryCandidate? {
        val lower = text.lowercase()

        // 1. Explicit Memory Commands: "تذكري إن...", "احفظي...", "سجلي عندج..."
        val explicitPrefixes = listOf(
            "تذكري ان", "تذكري إن", "تذكري أن", "تذكري",
            "احفظي ان", "احفظي إن", "احفظي أن", "احفظي عندج", "احفظي",
            "سجلي عندج", "سجلي عندك", "سجلي",
            "لا تنسين ان", "لا تنسين إن", "لا تنسين", "دربالج تنسين"
        )
        for (prefix in explicitPrefixes) {
            if (lower.startsWith(prefix)) {
                val clean = text.substring(prefix.length).trim().removePrefix("أن").removePrefix("إن").removePrefix("ان").trim()
                if (clean.length >= 3) {
                    val topic = inferTopicFromContent(clean)
                    val cat = inferCategory(clean, topic)
                    return MemoryCandidate(
                        title = topic,
                        content = clean,
                        category = cat,
                        importance = 4,
                        topicKeywords = extractKeywords(topic + " " + clean)
                    )
                }
            }
        }

        // 2. Name & Identity: "اسمي...", "أنا اسمي..."
        if (lower.contains("اسمي ") || lower.startsWith("انا اسمي") || lower.startsWith("أنا اسمي")) {
            val namePart = text.substringAfter("اسمي").trim().removePrefix(":").removePrefix("هو").trim()
            if (namePart.isNotBlank() && namePart.length < 50) {
                return MemoryCandidate(
                    title = "الاسم الشخصي",
                    content = "اسم المستخدم: $namePart",
                    category = "personal",
                    importance = 5,
                    topicKeywords = listOf("اسم", "اسمي", "هوية", "شخصي")
                )
            }
        }

        // 3. Health & Allergies: "عندي حساسية من...", "مريض سكر..."
        if (lower.contains("حساسية من") || lower.contains("عندي حساسية") || lower.contains("ممنوع من أكل") || lower.contains("ما أكل") || lower.contains("نباتي")) {
            return MemoryCandidate(
                title = "محاذير صحية وحساسية",
                content = text.trim(),
                category = "personal",
                importance = 5,
                topicKeywords = listOf("حساسية", "صحة", "أكل", "نباتي", "طعام")
            )
        }

        // 4. Profession & Work: "أشتغل...", "أعمل...", "وظيفتي...", "مهنتي...", "شغلي في...", "غيرت شغلي..."
        if (lower.contains("أشتغل") || lower.contains("اشتغل") || lower.contains("أعمل") || lower.contains("اعمل") ||
            lower.contains("وظيفتي") || lower.contains("مهنتي") || lower.contains("مقر عملي") || lower.contains("شغلي") ||
            lower.contains("غيرت شغلي") || lower.contains("غيرت وظيفتي") ||
            lower.startsWith("انا مهندس") || lower.startsWith("أنا مهندس") || lower.startsWith("انا دكتور") || lower.startsWith("أنا دكتور") ||
            lower.startsWith("انا محامي") || lower.startsWith("أنا محامي") || lower.startsWith("انا معلم") || lower.startsWith("أنا معلم")
        ) {
            return MemoryCandidate(
                title = "المهنة والوظيفة",
                content = text.trim(),
                category = "work",
                importance = 4,
                topicKeywords = listOf("عمل", "شغل", "وظيفة", "مهنة", "دوام")
            )
        }

        // 5. Work Hours & Routine: "دوامي من...", "دوامي يبدأ...", "أصحى الساعة..."
        if (lower.contains("دوامي يبدأ") || lower.contains("دوامي من") || lower.contains("ساعات دوامي") || lower.contains("أصحى الساعة") || lower.contains("اصحى الساعة")) {
            return MemoryCandidate(
                title = "مواعيد الدوام والروتين",
                content = text.trim(),
                category = "work",
                importance = 4,
                topicKeywords = listOf("دوام", "مواعيد", "ساعات", "روتين")
            )
        }

        // 6. Residence & Location: "ساكن في...", "بيتي في...", "انتقلت إلى..."
        if (lower.contains("ساكن في") || lower.contains("بيتي في") || lower.contains("انتقلت إلى") || lower.contains("انتقلت حق") || lower.contains("منطقتي هي")) {
            return MemoryCandidate(
                title = "مكان السكن والموقع",
                content = text.trim(),
                category = "personal",
                importance = 4,
                topicKeywords = listOf("سكن", "بيت", "منطقة", "مكان")
            )
        }

        // 7. Food & Drinks Preferences: "أحب القهوة...", "أفضل الشاي...", "مشروبي المفضل..."
        if (lower.contains("أحب القهوة") || lower.contains("احب القهوة") || lower.contains("أفضل الشاي") || lower.contains("افضل الشاي") ||
            lower.contains("قهوتي المفضلة") || lower.contains("مشروبي المفضل") || lower.contains("أحب أكل") || lower.contains("مطعمي المفضل")
        ) {
            val isDrink = lower.contains("قهوة") || lower.contains("شاي") || lower.contains("مشروب")
            return MemoryCandidate(
                title = if (isDrink) "تفضيل القهوة والمشروبات" else "تفضيلات الطعام والمطاعم",
                content = text.trim(),
                category = "preference",
                importance = 4,
                topicKeywords = if (isDrink) listOf("قهوة", "شاي", "مشروب", "مشروبات") else listOf("أكل", "طعام", "مطعم", "مطاعم")
            )
        }

        // 8. Vehicle & Car: "سيارتي..."
        if (lower.contains("سيارتي ") || lower.contains("سيارتي هي")) {
            return MemoryCandidate(
                title = "السيارة ووسيلة النقل",
                content = text.trim(),
                category = "personal",
                importance = 3,
                topicKeywords = listOf("سيارة", "مركبة", "قيادة")
            )
        }

        // 9. General Strong Preferences: "أنا أحب...", "أفضل دائماً...", "ما أحب...", "ما أواطن..."
        if (lower.startsWith("أنا أحب ") || lower.startsWith("انا احب ") || lower.startsWith("أفضل دائما") || lower.startsWith("افضل دائما") ||
            lower.contains("ما أواطن") || lower.contains("ما اواطن") || lower.contains("أكره") || lower.contains("ما أحب أبداً")
        ) {
            val snippet = text.take(30).trim()
            return MemoryCandidate(
                title = "تفضيل: $snippet",
                content = text.trim(),
                category = "preference",
                importance = 3,
                topicKeywords = extractKeywords(text)
            )
        }

        return null
    }

    private fun inferTopicFromContent(content: String): String {
        val lower = content.lowercase()
        return when {
            lower.contains("اسم") -> "الاسم الشخصي"
            lower.contains("قهوة") || lower.contains("شاي") || lower.contains("مشروب") -> "تفضيل القهوة والمشروبات"
            lower.contains("أكل") || lower.contains("مطعم") || lower.contains("طعام") -> "تفضيلات الطعام والمطاعم"
            lower.contains("دوام") || lower.contains("شغل") || lower.contains("وظيفة") || lower.contains("مهنة") -> "المهنة والوظيفة"
            lower.contains("بيت") || lower.contains("سكن") || lower.contains("منطقة") -> "مكان السكن والموقع"
            lower.contains("سيارة") -> "السيارة ووسيلة النقل"
            lower.contains("حساسية") || lower.contains("صحة") || lower.contains("سكر") || lower.contains("ضغط") -> "محاذير صحية وحساسية"
            lower.contains("رياضة") || lower.contains("نادي") || lower.contains("جيم") -> "الرياضة والنشاط البدني"
            lower.contains("سفر") || lower.contains("طيران") || lower.contains("فندق") -> "تفضيلات السفر والسياحة"
            else -> "ملاحظة شخصية: ${content.take(25)}..."
        }
    }

    private fun inferCategory(content: String, topic: String): String {
        val combined = (content + " " + topic).lowercase()
        return when {
            combined.contains("دوام") || combined.contains("شغل") || combined.contains("وظيفة") || combined.contains("شركة") || combined.contains("عمل") -> "work"
            combined.contains("أحب") || combined.contains("أفضل") || combined.contains("قهوة") || combined.contains("طعام") || combined.contains("سفر") -> "preference"
            combined.contains("اسم") || combined.contains("سكن") || combined.contains("بيت") || combined.contains("صحة") || combined.contains("عائلة") -> "personal"
            else -> "general"
        }
    }

    private fun findMatchingMemory(candidate: MemoryCandidate, existing: List<Memory>): Memory? {
        for (mem in existing) {
            val existingTitleLower = mem.title.lowercase()
            val candidateTitleLower = candidate.title.lowercase()

            if (existingTitleLower == candidateTitleLower) {
                return mem
            }

            // Keyword match across titles or topic
            val matchesTopic = candidate.topicKeywords.any { kw ->
                existingTitleLower.contains(kw) || mem.content.lowercase().contains(kw)
            }
            if (matchesTopic && (mem.category == candidate.category || candidate.category == "general" || mem.category == "general")) {
                return mem
            }
        }
        return null
    }

    private fun extractKeywords(text: String): List<String> {
        val stopWords = setOf(
            "في", "من", "على", "إلى", "عن", "مع", "هذا", "هذه", "التي", "الذي", "أنا", "انا",
            "إن", "ان", "أن", "ما", "لا", "هو", "هي", "هم", "كان", "كانت", "يكون", "ترى", "حق", "يفضل"
        )
        return text.split(Regex("[\\s,،.?!:;]+"))
            .map { it.trim().lowercase() }
            .filter { it.length >= 3 && it !in stopWords }
            .distinct()
            .take(6)
    }

    private fun normalizeForComparison(text: String): String {
        return text.lowercase()
            .replace(Regex("[\\s,،.?!:;]+"), " ")
            .replace("أ", "ا")
            .replace("إ", "ا")
            .replace("آ", "ا")
            .replace("ة", "ه")
            .replace("ى", "ي")
            .trim()
    }
}
