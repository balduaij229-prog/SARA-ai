package com.example.util

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.example.data.model.SaraVoiceMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

private const val TAG = "VoiceManager"

/**
 * Manages Text-To-Speech for SARA AI with a warm, natural Kuwaiti voice profile.
 */
class SaraTtsManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _currentUtteranceId = MutableStateFlow<String?>(null)
    val currentUtteranceId: StateFlow<String?> = _currentUtteranceId.asStateFlow()

    private val _currentVoiceMode = MutableStateFlow(SaraVoiceMode.FRIENDLY_KUWAITI)
    val currentVoiceMode: StateFlow<SaraVoiceMode> = _currentVoiceMode.asStateFlow()

    fun setVoiceMode(mode: SaraVoiceMode) {
        _currentVoiceMode.value = mode
        tts?.setPitch(mode.pitch)
        tts?.setSpeechRate(mode.speed)
        Log.d(TAG, "Applied voice mode: ${mode.id} (pitch: ${mode.pitch}, speed: ${mode.speed})")
    }

    init {
        initTts()
    }

    private fun initTts() {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                configureKuwaitiVoice()
                isInitialized = true
            } else {
                Log.w(TAG, "TextToSpeech initialization failed with status $status")
            }
        }
    }

    private fun configureKuwaitiVoice() {
        val engine = tts ?: return

        // 1. Target Arabic Kuwait locale
        val kuwaitLocale = Locale("ar", "KW")
        val arabicLocale = Locale("ar")

        val langResult = try {
            val res = engine.isLanguageAvailable(kuwaitLocale)
            if (res >= TextToSpeech.LANG_AVAILABLE) {
                engine.language = kuwaitLocale
                res
            } else {
                engine.language = arabicLocale
                engine.isLanguageAvailable(arabicLocale)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting language locale", e)
            TextToSpeech.LANG_NOT_SUPPORTED
        }

        // 2. Select the most natural voice (preferring Kuwait / Arabic female / high quality voice)
        try {
            val voices = engine.voices
            if (!voices.isNullOrEmpty()) {
                val bestVoice = voices.find { voice ->
                    val isAr = voice.locale?.language.equals("ar", ignoreCase = true)
                    val isKw = voice.locale?.country.equals("KW", ignoreCase = true)
                    val isFemale = voice.name.contains("female", ignoreCase = true) ||
                            voice.name.contains("fem", ignoreCase = true) ||
                            voice.name.contains("woman", ignoreCase = true)
                    isAr && (isKw || isFemale)
                } ?: voices.find { voice ->
                    voice.locale?.language.equals("ar", ignoreCase = true)
                }

                if (bestVoice != null) {
                    engine.voice = bestVoice
                    Log.d(TAG, "Selected TTS voice: ${bestVoice.name} (${bestVoice.locale})")
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Voice selection fallback: ${e.message}")
        }

        // 3. Audio characteristics for SARA: applied based on active voice mode
        val activeMode = _currentVoiceMode.value
        engine.setPitch(activeMode.pitch)
        engine.setSpeechRate(activeMode.speed)

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                mainHandler.post {
                    _isSpeaking.value = true
                    _currentUtteranceId.value = utteranceId
                }
            }

            override fun onDone(utteranceId: String?) {
                mainHandler.post {
                    _isSpeaking.value = false
                    _currentUtteranceId.value = null
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                mainHandler.post {
                    _isSpeaking.value = false
                    _currentUtteranceId.value = null
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                mainHandler.post {
                    _isSpeaking.value = false
                    _currentUtteranceId.value = null
                }
            }
        })
    }

    /**
     * Speaks text aloud using SARA's voice. Cleans markdown/code blocks for pleasant listening.
     */
    fun speak(text: String, utteranceId: String = "sara_${System.currentTimeMillis()}") {
        val cleanText = sanitizeTextForSpeech(text)
        if (cleanText.isBlank()) return

        if (tts == null || !isInitialized) {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    configureKuwaitiVoice()
                    isInitialized = true
                    tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
                }
            }
        } else {
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        }
    }

    fun stop() {
        try {
            tts?.stop()
        } catch (_: Exception) {}
        _isSpeaking.value = false
        _currentUtteranceId.value = null
    }

    fun shutdown() {
        stop()
        try {
            tts?.shutdown()
        } catch (_: Exception) {}
        tts = null
        isInitialized = false
    }

    private fun sanitizeTextForSpeech(input: String): String {
        return input
            // Remove code blocks
            .replace(Regex("```[\\s\\S]*?```"), "كود برمجي")
            // Remove inline code
            .replace(Regex("`[^`]*`"), "")
            // Remove markdown links [title](url) -> title
            .replace(Regex("\\[([^\\]]+)\\]\\([^\\)]+\\)"), "$1")
            // Remove headers #, ##, etc.
            .replace(Regex("#{1,6}\\s*"), "")
            // Remove markdown bullets and stars
            .replace(Regex("[*•_~]"), " ")
            // Normalize spaces
            .replace(Regex("\\s+"), " ")
            .trim()
    }
}

/**
 * State of speech recognition for UI feedback
 */
sealed class SpeechRecognitionState {
    object Idle : SpeechRecognitionState()
    object Ready : SpeechRecognitionState()
    data class Listening(val partialText: String = "", val rms: Float = 0f) : SpeechRecognitionState()
    data class Recognized(val text: String) : SpeechRecognitionState()
    data class Error(val message: String) : SpeechRecognitionState()
}

/**
 * Manages Speech-To-Text (Voice input) with Kuwaiti Arabic recognition.
 */
class SaraSttManager(private val context: Context) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _state = MutableStateFlow<SpeechRecognitionState>(SpeechRecognitionState.Idle)
    val state: StateFlow<SpeechRecognitionState> = _state.asStateFlow()

    private val _isAvailable = MutableStateFlow(SpeechRecognizer.isRecognitionAvailable(context))
    val isAvailable: StateFlow<Boolean> = _isAvailable.asStateFlow()

    fun isRecognitionAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(onResult: ((String) -> Unit)? = null) {
        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createListener(onResult))
                    }
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-KW")
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ar-KW")
                    putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "تكلم، سارة تسمعك...")
                }

                _state.value = SpeechRecognitionState.Ready
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Error starting speech recognition", e)
                _state.value = SpeechRecognitionState.Error("تعذر تشغيل التعرف الصوتي: ${e.message}")
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {}
        }
    }

    fun cancelListening() {
        mainHandler.post {
            try {
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
            _state.value = SpeechRecognitionState.Idle
        }
    }

    fun destroy() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
            } catch (_: Exception) {}
            speechRecognizer = null
            _state.value = SpeechRecognitionState.Idle
        }
    }

    private fun createListener(onResult: ((String) -> Unit)?): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = SpeechRecognitionState.Listening(partialText = "", rms = 0f)
            }

            override fun onBeginningOfSpeech() {
                _state.value = SpeechRecognitionState.Listening(partialText = "", rms = 2f)
            }

            override fun onRmsChanged(rmsdB: Float) {
                val currentState = _state.value
                if (currentState is SpeechRecognitionState.Listening) {
                    _state.value = currentState.copy(rms = rmsdB.coerceAtLeast(0f))
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                // Keep the current partial or transition to waiting for final result
            }

            override fun onError(error: Int) {
                val message = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "ما سمعت صوت واضح يا الغالي، جرب تتكلم مرة ثانية."
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "انتهى الوقت ولم يتم سماع صوت. اضغط المايك للمحاولة مجدداً."
                    SpeechRecognizer.ERROR_AUDIO -> "حدث خطأ في التقاط الصوت من الميكروفون."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "يرجى منح إذن الميكروفون لاستخدام الصوت مع سارة."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "مشكلة في الاتصال بالشبكة لخدمة الصوت."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "خدمة التعرف الصوتي مشغولة، جرب بعد لحظات."
                    else -> "تعذر التقاط الصوت (رمز الخطأ: $error)."
                }
                Log.w(TAG, "SpeechRecognizer error: $error ($message)")
                _state.value = SpeechRecognitionState.Error(message)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognized = matches?.firstOrNull()?.trim()
                if (!recognized.isNullOrBlank()) {
                    _state.value = SpeechRecognitionState.Recognized(recognized)
                    onResult?.invoke(recognized)
                } else {
                    _state.value = SpeechRecognitionState.Error("ما سمعت كلام واضح، جرب مرة ثانية.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val partial = matches?.firstOrNull()?.trim().orEmpty()
                if (partial.isNotBlank()) {
                    val currentRms = (_state.value as? SpeechRecognitionState.Listening)?.rms ?: 1f
                    _state.value = SpeechRecognitionState.Listening(partialText = partial, rms = currentRms)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }
}
