package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

data class ExtractedDocumentData(
    val fileName: String,
    val fileType: String, // "pdf", "text", "image"
    val textContent: String,
    val previewBitmap: Bitmap? = null,
    val fileSizeBytes: Long = 0L,
    val pageCount: Int = 1
)

object DocumentExtractor {
    private const val TAG = "DocumentExtractor"

    fun extract(context: Context, uri: Uri): ExtractedDocumentData {
        val fileName = getFileName(context, uri)
        val fileSizeBytes = getFileSizeBytes(context, uri)
        val mimeType = context.contentResolver.getType(uri)?.lowercase().orEmpty()
        val isPdf = fileName.endsWith(".pdf", ignoreCase = true) || mimeType.contains("pdf")

        return if (isPdf) {
            extractPdfDocument(context, uri, fileName, fileSizeBytes)
        } else {
            extractTextDocument(context, uri, fileName, fileSizeBytes)
        }
    }

    private fun extractPdfDocument(
        context: Context,
        uri: Uri,
        fileName: String,
        fileSizeBytes: Long
    ): ExtractedDocumentData {
        var pageCount = 1
        var previewBitmap: Bitmap? = null
        val rawTextBuilder = StringBuilder()

        try {
            val pfd: ParcelFileDescriptor? = context.contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                val renderer = PdfRenderer(pfd)
                pageCount = renderer.pageCount

                if (pageCount > 0) {
                    val page = renderer.openPage(0)
                    // Render at high resolution for Gemini multimodal OCR
                    val targetWidth = 1080
                    val scale = targetWidth.toFloat() / page.width.coerceAtLeast(1)
                    val targetHeight = (page.height * scale).toInt().coerceAtLeast(1)

                    val bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bmp)
                    canvas.drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    previewBitmap = bmp

                    page.close()
                }
                renderer.close()
                pfd.close()
            }
        } catch (e: Exception) {
            Log.w(TAG, "PdfRenderer preview extraction failed: ${e.message}")
        }

        // Try extracting any plain text streams from the PDF bytes
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val reader = BufferedReader(InputStreamReader(stream, StandardCharsets.ISO_8859_1))
                val buffer = CharArray(8192)
                var read = reader.read(buffer)
                var bytesParsed = 0
                while (read != -1 && bytesParsed < 500000) {
                    val chunk = String(buffer, 0, read)
                    // Extract text inside parenthesis (text in PDF objects)
                    val matches = Regex("\\(([^()]{3,200})\\)").findAll(chunk)
                    for (match in matches) {
                        val str = match.groupValues[1].trim()
                        if (str.any { it.isLetter() } && !str.contains("Font") && !str.contains("Obj")) {
                            rawTextBuilder.append(str).append(" ")
                        }
                    }
                    bytesParsed += read
                    read = reader.read(buffer)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "PDF stream plain text pass failed: ${e.message}")
        }

        val extractedText = rawTextBuilder.toString().trim()

        return ExtractedDocumentData(
            fileName = fileName,
            fileType = "pdf",
            textContent = extractedText,
            previewBitmap = previewBitmap,
            fileSizeBytes = fileSizeBytes,
            pageCount = pageCount
        )
    }

    private fun extractTextDocument(
        context: Context,
        uri: Uri,
        fileName: String,
        fileSizeBytes: Long
    ): ExtractedDocumentData {
        var textContent = ""
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                val reader = BufferedReader(InputStreamReader(stream, StandardCharsets.UTF_8))
                textContent = reader.readText().take(60000)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading text document: ${e.message}", e)
            textContent = "تعذر قراءة محتوى المستند بالكامل."
        }

        return ExtractedDocumentData(
            fileName = fileName,
            fileType = "text",
            textContent = textContent,
            previewBitmap = null,
            fileSizeBytes = fileSizeBytes,
            pageCount = 1
        )
    }

    private fun getFileName(context: Context, uri: Uri): String {
        var name = uri.lastPathSegment ?: "document.txt"
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (nameIndex != -1 && cursor.moveToFirst()) {
                    name = cursor.getString(nameIndex) ?: name
                }
            }
        } catch (_: Exception) {}
        return name
    }

    private fun getFileSizeBytes(context: Context, uri: Uri): Long {
        var size = 0L
        try {
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (sizeIndex != -1 && cursor.moveToFirst()) {
                    size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {}
        return size
    }

    fun formatFileSize(bytes: Long): String {
        return when {
            bytes <= 0L -> "0 B"
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0)
            else -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }
}
