package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.util.UUID

class SaraRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createMemory_authenticatedOwner_createsDocument() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = SaraRepository(firestore)

        val result = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addMemory("قهوة الصباح", "يفضل قهوة فلات وايت بدون سكر", "preference", 5)
        }
        assertTrue(result.isSuccess)
        val memoryId = result.getOrThrow()
        assertTrue(memoryId.isNotEmpty())
    }

    @Test
    fun observeMemories_authenticatedOwner_emitsMemories() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = SaraRepository(firestore)

        val memoryId = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.addMemory("الأماكن المفضلة", "مجمع الأفنيوز في عطلة نهاية الأسبوع", "personal", 4).getOrThrow()
        }

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeMemories().first { list -> list.any { it.id == memoryId } }
        }
        assertTrue(emitted.any { it.id == memoryId })
    }

    @Test
    fun observeMemories_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        auth.signOut()
        val repository = SaraRepository(firestore)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeMemories().first()
            }
            fail("Expected exception for unauthenticated user")
        } catch (e: Exception) {
            // Unauthenticated user fails fail-fast in repository requireUserId or rules
            assertNotNull(e.message)
        }
    }

    private companion object {
        val ALICE_EMAIL = "alice_${UUID.randomUUID().toString().take(6)}@test.com"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
