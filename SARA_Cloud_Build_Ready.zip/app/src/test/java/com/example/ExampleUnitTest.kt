package com.example

import com.example.data.model.Memory
import com.example.data.model.Message
import com.example.util.MemoryDecision
import com.example.util.SaraMemoryEngine
import com.google.firebase.Timestamp
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Date

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun messages_areSortedStrictlyChronological() {
        val now = System.currentTimeMillis()
        val msg1 = Message(
            id = "msg_1",
            role = "user",
            content = "هلا سارة",
            createdAt = Timestamp(Date(now - 10000))
        )
        val msg2 = Message(
            id = "msg_2",
            role = "model",
            content = "يا هلا ومسهلا! شلونك اليوم؟",
            createdAt = Timestamp(Date(now - 5000))
        )
        val msg3 = Message(
            id = "msg_3",
            role = "user",
            content = "تمام الحمدلله، شنو اقتراحاتك؟",
            createdAt = Timestamp(Date(now - 1000))
        )
        val pendingMsg = Message(
            id = "msg_4_pending",
            role = "model",
            content = "جاري الحفظ...",
            createdAt = null // Pending server timestamp
        )

        // Random order input
        val unsortedList = listOf(msg2, pendingMsg, msg1, msg3)

        val sortedList = unsortedList.sortedWith(
            compareBy<Message> { it.createdAt?.toDate()?.time ?: Long.MAX_VALUE }
                .thenBy { it.id }
        )

        assertEquals("msg_1", sortedList[0].id)
        assertEquals("user", sortedList[0].role)

        assertEquals("msg_2", sortedList[1].id)
        assertEquals("model", sortedList[1].role)

        assertEquals("msg_3", sortedList[2].id)
        assertEquals("user", sortedList[2].role)

        assertEquals("msg_4_pending", sortedList[3].id)
        assertEquals("model", sortedList[3].role)
    }

    @Test
    fun messages_differentiateUserAndModelStylingRoles() {
        val userMsg = Message(id = "1", role = "user", content = "رسالة المستخدم")
        val modelMsg = Message(id = "2", role = "model", content = "رد سارة الكويتية")

        assertTrue(userMsg.role == "user")
        assertTrue(modelMsg.role == "model")
    }

    @Test
    fun quickActions_generateExpectedContextualPrompts() {
        val testMessage = Message(
            id = "last_msg",
            role = "model",
            content = "الكويت تتميز بتراث عريق وأماكن سياحية رائعة مثل أبراج الكويت وسوق المباركية ومركز الشيخ جابر الأحمد الثقافي."
        )

        val summarizePrompt = com.example.ui.components.buildQuickActionPrompt(
            com.example.ui.components.QuickActionType.SUMMARIZE,
            testMessage
        )
        assertTrue(summarizePrompt.contains("لخص لي"))
        assertTrue(summarizePrompt.contains("أبراج الكويت"))

        val translatePrompt = com.example.ui.components.buildQuickActionPrompt(
            com.example.ui.components.QuickActionType.TRANSLATE_EN,
            testMessage
        )
        assertTrue(translatePrompt.contains("ترجم لي"))
        assertTrue(translatePrompt.contains("اللغة الإنجليزية"))

        val draftReplyPrompt = com.example.ui.components.buildQuickActionPrompt(
            com.example.ui.components.QuickActionType.DRAFT_REPLY,
            testMessage
        )
        assertTrue(draftReplyPrompt.contains("اكتب رد") || draftReplyPrompt.contains("صغ لي"))
        assertTrue(draftReplyPrompt.contains("كويتية"))

        val explainPrompt = com.example.ui.components.buildQuickActionPrompt(
            com.example.ui.components.QuickActionType.EXPLAIN_MORE,
            testMessage
        )
        assertTrue(explainPrompt.contains("توضحين") || explainPrompt.contains("تشرحين") || explainPrompt.contains("أمثلة"))
    }

    @Test
    fun quickActions_handlesLongMessageTruncation() {
        val longContent = "أ".repeat(500)
        val longMessage = Message(id = "long_msg", role = "user", content = longContent)

        val prompt = com.example.ui.components.buildQuickActionPrompt(
            com.example.ui.components.QuickActionType.SUMMARIZE,
            longMessage
        )

        assertTrue(prompt.contains("..."))
        assertTrue(prompt.length < 500)
    }

    @Test
    fun voiceModes_haveDistinctParametersAndValidFallbacks() {
        // Test fallback for unknown ID
        val defaultMode = com.example.data.model.SaraVoiceMode.fromId("unknown_mode")
        assertEquals(com.example.data.model.SaraVoiceMode.FRIENDLY_KUWAITI, defaultMode)

        // Test explicit resolution
        val proMode = com.example.data.model.SaraVoiceMode.fromId("professional")
        assertEquals(com.example.data.model.SaraVoiceMode.PROFESSIONAL_OFFICIAL, proMode)

        val calmMode = com.example.data.model.SaraVoiceMode.fromId("calm_concise")
        assertEquals(com.example.data.model.SaraVoiceMode.CALM_CONCISE, calmMode)

        val storyMode = com.example.data.model.SaraVoiceMode.fromId("storyteller")
        assertEquals(com.example.data.model.SaraVoiceMode.STORYTELLER, storyMode)

        // Verify all 4 modes have valid pitch, speed, and Arabic instruction
        com.example.data.model.SaraVoiceMode.values().forEach { mode ->
            assertTrue("Pitch must be positive for ${mode.name}", mode.pitch in 0.5f..2.0f)
            assertTrue("Speed must be positive for ${mode.name}", mode.speed in 0.5f..2.0f)
            assertTrue("Sample text must not be blank for ${mode.name}", mode.sampleText.isNotBlank())
            assertTrue("Prompt instruction must not be blank for ${mode.name}", mode.promptInstruction.isNotBlank())
        }
    }

    @Test
    fun userProfile_defaultValuesSupportVoiceModeAndMemoryPrivacy() {
        val profile = com.example.data.model.UserProfile(
            id = "test_user",
            userId = "test_user",
            displayName = "أحمد"
        )

        assertEquals("friendly_kuwaiti", profile.voiceMode)
        assertTrue(profile.memoryPrivacyEnabled)
        assertEquals("kuwaiti", profile.preferredDialect)
    }

    @Test
    fun learnedDocument_supportsPdfAndTextProperties() {
        val pdfDoc = com.example.data.model.LearnedDocument(
            id = "doc_pdf_1",
            title = "تقرير_الاستثمار_الكويتي.pdf",
            summary = "تقرير مفصل عن الصندوق السيادي الكويتي لعام 2024",
            extractedContent = "• ارتفاع الأرباح بنسبة 12%\n• استثمارات جديدة في الطاقة المتجددة",
            fileType = "pdf",
            fileSizeBytes = 2_500_000L,
            pageCount = 14
        )

        assertEquals("pdf", pdfDoc.fileType)
        assertEquals(2_500_000L, pdfDoc.fileSizeBytes)
        assertEquals(14, pdfDoc.pageCount)
        assertTrue(pdfDoc.extractedContent.contains("ارتفاع الأرباح"))

        val textDoc = com.example.data.model.LearnedDocument(
            id = "doc_txt_1",
            title = "ملاحظات_الاجتماع.txt",
            summary = "محضر اجتماع مجلس الإدارة",
            extractedContent = "• الموافقة على الخطة السنوية",
            fileType = "text",
            fileSizeBytes = 1024L,
            pageCount = 1
        )

        assertEquals("text", textDoc.fileType)
        assertEquals(1024L, textDoc.fileSizeBytes)
        assertEquals(1, textDoc.pageCount)
    }

    @Test
    fun documentExtractor_formatsFileSizeAccurately() {
        assertEquals("0 B", com.example.util.DocumentExtractor.formatFileSize(0L))
        assertEquals("512 B", com.example.util.DocumentExtractor.formatFileSize(512L))
        assertEquals("1.0 KB", com.example.util.DocumentExtractor.formatFileSize(1024L))
        assertEquals("1.5 KB", com.example.util.DocumentExtractor.formatFileSize(1536L))
        assertEquals("2.4 MB", com.example.util.DocumentExtractor.formatFileSize(2_500_000L))
    }

    @Test
    fun chatMessageScreen_formatsDatesAndTimesProperly() {
        assertEquals("اليوم", com.example.ui.components.formatDateHeader(null))
        assertEquals("today", com.example.ui.components.getDateKey(null))
        assertEquals("الآن", com.example.ui.components.formatMessageTime(null))

        val nowTimestamp = Timestamp(Date())
        assertEquals("اليوم", com.example.ui.components.formatDateHeader(nowTimestamp))
        assertTrue(com.example.ui.components.formatMessageTime(nowTimestamp).isNotBlank())
    }

    @Test
    fun chatMessageScreen_distinguishesUserAndSaraBubbleColorsAndAlignments() {
        val userStyle = com.example.ui.screens.resolveMessageBubbleStyle(role = "user", isSpeaking = false)
        val saraStyle = com.example.ui.screens.resolveMessageBubbleStyle(role = "model", isSpeaking = false)
        val saraSpeakingStyle = com.example.ui.screens.resolveMessageBubbleStyle(role = "model", isSpeaking = true)

        // Role flags
        assertTrue(userStyle.isUser)
        assertTrue(!saraStyle.isUser)

        // Distinct bubble background colors
        assertNotEquals(userStyle.bubbleColor, saraStyle.bubbleColor)
        assertEquals(com.example.ui.theme.UserBubble, userStyle.bubbleColor)
        assertEquals(com.example.ui.theme.SaraBubble, saraStyle.bubbleColor)

        // Distinct alignments (End for User vs Start for SARA AI)
        assertEquals(androidx.compose.foundation.layout.Arrangement.End, userStyle.horizontalArrangement)
        assertEquals(androidx.compose.foundation.layout.Arrangement.Start, saraStyle.horizontalArrangement)
        assertEquals(androidx.compose.ui.Alignment.End, userStyle.columnAlignment)
        assertEquals(androidx.compose.ui.Alignment.Start, saraStyle.columnAlignment)
        assertEquals(androidx.compose.ui.Alignment.CenterEnd, userStyle.boxAlignment)
        assertEquals(androidx.compose.ui.Alignment.CenterStart, saraStyle.boxAlignment)

        // Distinct headers and speaking state highlight
        assertEquals("أنت", userStyle.headerLabel)
        assertTrue(saraStyle.headerLabel.contains("سارة"))
        assertEquals(com.example.ui.theme.KuwaitEmerald, saraSpeakingStyle.headerColor)
    }

    // ==========================================
    // SARA AI Memory Engine & Deduplication Tests
    // ==========================================

    @Test
    fun memoryEngine_extractsNewPreferenceAutomatically() {
        val userInput = "أحب القهوة التركية مع هيل وبدون سكر"
        val existingMemories = emptyList<Memory>()

        val decision = SaraMemoryEngine.analyzeAndDecide(userInput, existingMemories)
        assertTrue("Decision should be Create", decision is MemoryDecision.Create)

        val create = decision as MemoryDecision.Create
        assertEquals("preference", create.category)
        assertTrue(create.title.contains("القهوة") || create.title.contains("تفضيل"))
        assertTrue(create.content.contains("القهوة التركية") || create.content.contains("بدون سكر"))
        assertEquals(4, create.importance)
    }

    @Test
    fun memoryEngine_extractsPersonalIdentityAndAllergies() {
        // Name test
        val nameInput = "اسمي ناصر وأنا من الكويت"
        val nameDecision = SaraMemoryEngine.analyzeAndDecide(nameInput, emptyList())
        assertTrue(nameDecision is MemoryDecision.Create)
        val nameCreate = nameDecision as MemoryDecision.Create
        assertEquals("personal", nameCreate.category)
        assertEquals("الاسم الشخصي", nameCreate.title)
        assertTrue(nameCreate.content.contains("ناصر"))
        assertEquals(5, nameCreate.importance)

        // Allergy test
        val allergyInput = "عندي حساسية شديدة من المكسرات والفول السوداني"
        val allergyDecision = SaraMemoryEngine.analyzeAndDecide(allergyInput, emptyList())
        assertTrue(allergyDecision is MemoryDecision.Create)
        val allergyCreate = allergyDecision as MemoryDecision.Create
        assertEquals("personal", allergyCreate.category)
        assertTrue(allergyCreate.title.contains("حساسية"))
        assertTrue(allergyCreate.content.contains("المكسرات"))
        assertEquals(5, allergyCreate.importance)
    }

    @Test
    fun memoryEngine_extractsProfessionAndWork() {
        val workInput = "أنا أشتغل مهندس برمجيات في القطاع الحكومي"
        val decision = SaraMemoryEngine.analyzeAndDecide(workInput, emptyList())
        assertTrue(decision is MemoryDecision.Create)

        val create = decision as MemoryDecision.Create
        assertEquals("work", create.category)
        assertEquals("المهنة والوظيفة", create.title)
        assertTrue(create.content.contains("مهندس برمجيات"))
    }

    @Test
    fun memoryEngine_preventsDuplicatesWhenExactOrSimilarInfoExists() {
        val existing = listOf(
            Memory(
                id = "mem_coffee_1",
                userId = "u1",
                title = "تفضيل القهوة",
                content = "يفضل القهوة التركية بدون سكر",
                category = "preference",
                importance = 4
            )
        )

        // Repetitive statement containing already known facts
        val duplicateInput = "أنا أحب القهوة التركية بدون سكر"
        val decision = SaraMemoryEngine.analyzeAndDecide(duplicateInput, existing)

        assertTrue(
            "Duplicate or identical fact should yield NoChange",
            decision is MemoryDecision.NoChange
        )
    }

    @Test
    fun memoryEngine_updatesExistingMemoryWhenUserCorrectsInformation() {
        val existingWorkMemory = Memory(
            id = "mem_work_99",
            userId = "u1",
            title = "المهنة والوظيفة",
            content = "يعمل كـ مهندس برمجيات",
            category = "work",
            importance = 4
        )

        // User states that their job changed
        val correctionInput = "غيرت وظيفتي إلى مدير مشاريع تقنية"
        val decision = SaraMemoryEngine.analyzeAndDecide(correctionInput, listOf(existingWorkMemory))

        assertTrue("Should detect update to existing job memory", decision is MemoryDecision.Update)
        val update = decision as MemoryDecision.Update
        assertEquals("mem_work_99", update.existingMemoryId)
        assertTrue(update.content.contains("مدير مشاريع تقنية"))
    }

    @Test
    fun memoryEngine_ignoresGeneralChatterWithoutLearningFalsely() {
        val casualChat = "السلام عليكم يا سارة، شلون الجو اليوم بالديرة؟"
        val decision = SaraMemoryEngine.analyzeAndDecide(casualChat, emptyList())

        assertTrue("Casual questions should NOT create long-term memories", decision is MemoryDecision.NoChange)

        val mathQuestion = "كم حاصل ضرب 15 في 4؟"
        val mathDecision = SaraMemoryEngine.analyzeAndDecide(mathQuestion, emptyList())
        assertTrue(mathDecision is MemoryDecision.NoChange)
    }

    @Test
    fun memoryEngine_ensuresMemoryIsSeparatedFromChatHistory() {
        // Chat messages have role 'user' or 'model' and live in conversations/{convId}/messages
        val chatMessage = Message(
            id = "msg_chat_1",
            role = "user",
            content = "أحب القهوة التركية",
            createdAt = Timestamp.now()
        )

        // Memory documents live under users/{userId}/memories with title, importance, category
        val memoryDoc = Memory(
            id = "mem_1",
            userId = "user_kuwait_1",
            title = "تفضيل القهوة",
            content = "يفضل القهوة التركية بدون سكر",
            category = "preference",
            importance = 4
        )

        assertNotEquals(chatMessage.id, memoryDoc.id)
        assertNotEquals(chatMessage.role, memoryDoc.category)
        assertTrue(chatMessage.role == "user")
        assertTrue(memoryDoc.category == "preference")
    }
}
